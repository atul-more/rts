package com.atul;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;

public class HibernateMain {

	public static void main(String[] args) {
		//Define object
		UserDetails user = new UserDetails();
		user.setUserId(10);
		user.setUserName("Tenth User");
		
		//Embedded object
		Address addr = new Address();
		addr.setCity("Sangli");
		addr.setStreet("Main Road");
		addr.setState("MH");
		addr.setPincode("415416");
		user.setAddress(addr);
		
		//User Hibernate API to save object
		/**
		 * Create Session Factory - based on cfg file. Only one obj per appl.
		 * Create Session - from Session Factory.
		 * Use Session to save model obj.
		 */
		SessionFactory sessionFactory = new Configuration().configure().buildSessionFactory();
		Session session = sessionFactory.openSession();
		session.beginTransaction();
		session.save(user);
		session.getTransaction().commit();
		session.close();
		
		/*user = null;
		session = sessionFactory.openSession();
		session.beginTransaction();
		user = session.get(UserDetails.class, 5);
		session.close();
		
		System.out.println(user.getUserId() + " " + user.getUserName());*/
		
		sessionFactory.close();
	}

}

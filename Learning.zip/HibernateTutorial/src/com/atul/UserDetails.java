/**
 * 
 */
package com.atul;

import javax.persistence.Entity;
import javax.persistence.Id;
//import javax.persistence.Table;
//import javax.persistence.Transient;


/**
 * @author am0011186
 *
 */

@Entity
//@Table (name="user_detail")
public class UserDetails {
	@Id
	private int userId;
	
	//@Transient
	private String userName;
	
	//@Embedded
	private Address address;
	
	/**
	 * @return the address
	 */
	public Address getAddress() {
		return address;
	}
	/**
	 * @param address the address to set
	 */
	public void setAddress(Address address) {
		this.address = address;
	}
	
	/**
	 * @return the userId
	 */
	public int getUserId() {
		return userId;
	}
	/**
	 * @param userId the userId to set
	 */
	public void setUserId(int userId) {
		this.userId = userId;
	}
	/**
	 * @return the userName
	 */
	public String getUserName() {
		return userName;
	}
	/**
	 * @param userName the userName to set
	 */
	public void setUserName(String userName) {
		this.userName = userName;
	}
}

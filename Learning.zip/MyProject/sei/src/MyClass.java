
public class MyClass {
	private static MyClass soleInstance = null;
	private MyClass() {
		
	}
	public static MyClass getInstance(){
		if(soleInstance == null)
			soleInstance = new MyClass();
		
		return soleInstance;
	}
}

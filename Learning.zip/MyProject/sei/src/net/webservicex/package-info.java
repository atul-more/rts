@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.webservicex.net/", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package net.webservicex;

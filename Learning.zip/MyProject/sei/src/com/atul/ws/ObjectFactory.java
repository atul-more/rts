
package com.atul.ws;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.atul.ws package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _GetProductCatalog_QNAME = new QName("http://ws.atul.com/", "getProductCatalog");
    private final static QName _GetProductCatalogResponse_QNAME = new QName("http://ws.atul.com/", "getProductCatalogResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.atul.ws
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link GetProductCatalogResponse }
     * 
     */
    public GetProductCatalogResponse createGetProductCatalogResponse() {
        return new GetProductCatalogResponse();
    }

    /**
     * Create an instance of {@link GetProductCatalog }
     * 
     */
    public GetProductCatalog createGetProductCatalog() {
        return new GetProductCatalog();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetProductCatalog }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.atul.com/", name = "getProductCatalog")
    public JAXBElement<GetProductCatalog> createGetProductCatalog(GetProductCatalog value) {
        return new JAXBElement<GetProductCatalog>(_GetProductCatalog_QNAME, GetProductCatalog.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetProductCatalogResponse }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://ws.atul.com/", name = "getProductCatalogResponse")
    public JAXBElement<GetProductCatalogResponse> createGetProductCatalogResponse(GetProductCatalogResponse value) {
        return new JAXBElement<GetProductCatalogResponse>(_GetProductCatalogResponse_QNAME, GetProductCatalogResponse.class, null, value);
    }

}

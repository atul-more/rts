package test.pkg;

public class A{
	public static void main(String... args) {
		System.out.println("hello java4");
		
		String menuInvoked = null;
		System.out.println(isEmptyString(menuInvoked));
		
		testMethod();
	}
	
	private static void testMethod() {
		String newString = "/initPdtsDiscussion.do";
		newString = newString.replace(".do", "");
		System.out.println(newString);
		
	}

	public static boolean isEmptyString(String str) {
		if ((str != null) && (str.trim().length() > 0)) {
			return false;
		}
		return true;
	}
}  
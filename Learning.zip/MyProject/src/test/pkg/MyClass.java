/**
 * 
 */
package test.pkg;

import java.net.MalformedURLException;
import java.net.URL;

/**
 * @author am0011186
 *
 */
public class MyClass {

	/**
	 * @param args
	 * @throws MalformedURLException 
	 */
	public static void main(String[] args) throws MalformedURLException {
		/*String url = "http://am5854.itservices.sbc.com:9001/webapp/createMyTeamDiscussion1.action?a=1&b=cad";
		URL newUrl = new URL(url);
		String urlPath = newUrl.getPath();
		String urlPathPortion[] = urlPath.split("/");
		System.out.println(urlPathPortion[urlPathPortion.length-1].replace(".action", ""));
		System.out.println(newUrl.getHost()); //am5854.itservices.sbc.com
		System.out.println(newUrl.getProtocol()); //http
		System.out.println(newUrl.getPath()); ///webapp/createMyTeamDiscussion1.action
		System.out.println(newUrl.getQuery()); //NULL
		System.out.println(newUrl.getUserInfo()); //NULL*/
		
		String [] str1 = {"abc", "pqa"};
		for (String string : str1) {
			System.out.println("A..." + string);
		}
		System.out.println(str1.length);
		
		
		
	}

}

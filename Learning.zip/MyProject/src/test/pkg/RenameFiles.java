package test.pkg;

import java.io.File; 
import java.util.StringTokenizer;

/** 
 * Change the extension name of the file recursively 
 * for multiple directories
 *  
*/ 

public class RenameFiles {
	static String reName =""; 
	static StringTokenizer str =null; 
	static File files[] =null; 
	static final String ext = ".sql";//Extension to Change to 

	public void renameFile(String path){ 
		String fileName, newName; 
		int extnIndex;
		try { 
			File file = new File(path); 
			files = file.listFiles(); 
			for(File fl : files){ 
				if(fl.isDirectory()){ 
					System.out.println("Directory name:" + fl.toString()); 
					renameFile(fl.toString()); 
				} else {
					if(fl.isFile()){ 
						fileName = fl.getName();
						extnIndex = fileName.lastIndexOf(".");
						
						if (extnIndex != -1) {
			            	newName = fileName.substring(0, extnIndex);
			            	newName = fl.getParent() + "\\" + newName + ext;
			            	/*if (fileName.substring(extnIndex + 1).equalsIgnoreCase("pkb")) {
			            		newName = fl.getParent() + "\\" + newName + "_BODY" + ext;
			            	} else if (fileName.substring(extnIndex + 1).equalsIgnoreCase("pks")) {
			            		newName = fl.getParent() + "\\" + newName + "_SPEC" + ext;
			            	}*/
							System.out.println("Changed Name " + newName); 
							fl.renameTo(new File(newName)); 
						}
					} else {
						System.out.println(fl.getName()+" Not A File! ");
					}
				}
			}
		} catch(Exception e){ 
			e.printStackTrace(); 
		} 
	}
	
	public static void main(String[] args) {
		String path = "D:/am0011186/ATT/App/_PDTS/WorkArea/Dev/Sustainment/In Progress/SVN Code Sync/DB Object Script/TYPES"; 
		RenameFiles re = new RenameFiles(); 
		re.renameFile(path);
	}
}

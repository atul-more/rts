package my.spring;

public class ProductA {

}

package my.spring;

/**
 * This is simple bean class, containing only one property name with its getters and setters method. 
 * This class contains one extra method named displayInfo() that prints the student name by the hello message.
 *
 */
public class Student { 
	private String name;
	private String titleOfName;
	  
	/**
	 * @return the titleOfName
	 */
	public String getTitleOfName() {
		return titleOfName;
	}

	/**
	 * @param titleOfName the titleOfName to set
	 */
	public void setTitleOfName(String titleOfName) {
		this.titleOfName = titleOfName;
	}

	public String getName() {  
	    return name;  
	}  
	  
	public void setName(String name) {  
	    this.name = name;  
	}  
	  
	public void displayInfo(){  
	    System.out.println("Hi " + name);
	    System.out.println(titleOfName);
	    System.out.println(getTitleOfName());
	}  
}  

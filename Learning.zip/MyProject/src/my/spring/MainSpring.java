package my.spring;

import org.springframework.beans.factory.BeanFactory;  
import org.springframework.beans.factory.xml.XmlBeanFactory;  
import org.springframework.core.io.ClassPathResource;  
import org.springframework.core.io.Resource;  
  
/**
 * Here we are getting the object of Student class 
 * from the IOC container using the getBean() method of BeanFactory.
 * 
 */
public class MainSpring {  

	public static void main(String[] args) {
		/**
		 * The Resource object represents the information of applicationContext.xml file. 
		 * The Resource is the interface and the ClassPathResource is the implementation class of the Resource interface. 
		 * The BeanFactory is responsible to return the bean. 
		 * The XmlBeanFactory is the implementation class of the BeanFactory.
		 */
	    Resource resource = new ClassPathResource("applicationContext.xml");  
	    BeanFactory factory = new XmlBeanFactory(resource);  
	      
	    Student student = (Student)factory.getBean("studentbean");  
	    student.displayInfo();  
	}  
}

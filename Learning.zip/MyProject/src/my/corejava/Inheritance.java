package my.corejava;

public class Inheritance {
	
	public int x() {
		return 1;
	}
	
	public static void main(String[] args) {
		Inheritance a = new B();
		Inheritance b = new Inheritance();
		int x = a.x();
		System.out.println("x = " + x);
		int x1 = b.x();
		System.out.println("x1 = " + x1);
	}
}

class B extends Inheritance {
	public int x() {
		return 2;
	}
}
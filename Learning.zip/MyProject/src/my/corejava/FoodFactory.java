package my.corejava;

/**
 * Expected output is:
 * 
 * 	My name is: my.corejava.FastFood
	My name is: my.corejava.Fruit
	Our superclass is: my.corejava.Food
	I am serving FastFood
	I am serving Fruit

 * 
 * @author am0011186
 *
 */
public class FoodFactory extends Food {
	public Food getFood(String name) {
		Food f = null;
		if (name.equals("FastFood")) {
            f = new FastFood();
            f.name = name;
        } else if (name.equals("Fruit")) {
            f = new Fruit();
            f.name = name;            
        }
		return f;
	}
	
	public static void main(String[] args) {
		FoodFactory myFoods = new FoodFactory();
		Food food1 = myFoods.getFood("FastFood");
		Food food2 = myFoods.getFood("Fruit");
		System.out.println("My name is: " + food1.getClass().getName());
		System.out.println("My name is: " + food2.getClass().getName());
		
		System.out.println("Our superclass is: " + food1.getClass().getSuperclass().getName());
		
		food1.serveFood();
		food2.serveFood();
		
	}
}

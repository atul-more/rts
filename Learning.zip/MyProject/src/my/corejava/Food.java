package my.corejava;

public class Food {
	protected String name;
	static void display() {
		System.out.println("test");
	}
	
	public void serveFood() {
		System.out.println("I am serving " + name);		
	}
}

class FastFood extends Food {
	
}

class Fruit extends Food {
}

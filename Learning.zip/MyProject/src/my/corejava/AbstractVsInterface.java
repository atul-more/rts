package my.corejava;

public class AbstractVsInterface {
	public static void main(String[] args) {
		Parent p = new Child();
		p.display();
		Child c = new Child();
		c.show();
	}
}

class Parent {
	String name;
	
	Parent() {
		System.out.println("Parent constructor called!!");
	}
	
	Parent(String name) {
		this.name = name;
	}
	
	public void display() {
		System.out.println("Displaying: " + name);
	}
}

class Child extends Parent {
	public void show() {
		System.out.println("Inside show = " + name);
	}
}

interface MyInterface {
	void myMethod();
	public abstract void myNewMethod(String name);
}

abstract class MyAbstractClass {
	//You need to override every abstract method in the class extending this abstract class.
	public abstract void myAbsClMethod1();
	public void myAbsClMethod2() {
		System.out.println("Inside abstract class impl");
	}
}

//extends should precede implements clause
class MyClass extends MyAbstractClass implements MyInterface {

	@Override
	public void myMethod() {
	
	}

	@Override
	public void myNewMethod(String name) {
		
	}

	@Override
	public void myAbsClMethod1() {
		
	}
	
}

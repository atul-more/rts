package my.corejava;

public class OutOfMemoryError {

	public static void main(String[] args) {
		

	}

}

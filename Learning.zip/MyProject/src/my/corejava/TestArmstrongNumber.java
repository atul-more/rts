package my.corejava;

public class TestArmstrongNumber {
	private boolean isArmstrongNumber(int n) {
		boolean flag = false;
		int num = 0, originalNum = n, cnt = 0;
		double sum = 0;
		
		for(int i = n; i > 0;) {
			//System.out.println(i);
			cnt++;
			i = i/10;			
		}
		
		//int arr[] = new int[cnt];
		for(int i = 0; i < cnt; i++) {
			num = n%10;
			sum = sum + Math.pow(num, (double)cnt);
			n = n/10;
		}
		
		if(sum == (double)originalNum) {
			flag = true;
		}
		
		return flag;
	}
	
	public static void main(String[] args) {
		TestArmstrongNumber tst = new TestArmstrongNumber();
		int num = 370;
		boolean isTrue = tst.isArmstrongNumber(num);
		System.out.println(isTrue == true ? true : false);
	}	

}

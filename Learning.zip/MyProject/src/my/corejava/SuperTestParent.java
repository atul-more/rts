package my.corejava;

public class SuperTestParent {

	public SuperTestParent() {
		System.out.println("in SuperTestParent constructor");
	}
}

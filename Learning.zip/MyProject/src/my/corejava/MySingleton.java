package my.corejava;

/**
 * Using static block
 * 
 * However, what happens if class creation is failed while loading the class.
 * It would throw some error in JVM and we don't have control on it.
 * 
 * If we use static method to create soleInstance instead of static block, any failure
 * to object creation will be subject to exception handling @ Application level (will be under control). 
 *  
 * 
 * @author am0011186
 *
 */
public class MySingleton {
	private static MySingleton soleInstance = null;
	
	static {
		soleInstance = new MySingleton();
		System.out.println("soleInstance:" + soleInstance.hashCode());
	}
	
	public static MySingleton getInstance() {
		return soleInstance;
	}
	
	private MySingleton() {
		
	}

	public static void main(String[] args) {
		System.out.println("Inside Main");
		MySingleton instance1 = MySingleton.getInstance();
		MySingleton instance2 = MySingleton.getInstance();
		System.out.println("instance1:" + instance1.hashCode());
		System.out.println("instance2:" + instance2.hashCode());
		
	}

}

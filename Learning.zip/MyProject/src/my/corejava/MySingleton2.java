package my.corejava;

/**
 *
 * This Singleton impl makes use of public static method to initialize only one class obj.
 * Uses synchronized block and double checking to avoid any further issues in implementing Singleton. 
 * 
 * Primitive variables can't be part of Synchronized block. Ex. Int, Float, Long, boolean etc.
 * Use java.util.concurrent.atomic.AtomicInteger instead. 
 * 
 * @author am0011186
 *
 */
public class MySingleton2 {
	private static volatile MySingleton2 soleInstance; 
	
	private MySingleton2() {
		
	}
	
	public static MySingleton2 getInstance() {
		if(soleInstance == null) {
			synchronized (MySingleton2.class) {
				if(soleInstance == null) //double checking
				soleInstance = new MySingleton2();	
			}			
		}
		
		return soleInstance; 
	}
	
	public static void main(String[] args) {
		System.out.println("Inside Main");
		MySingleton2 instance1 = MySingleton2.getInstance();
		MySingleton2 instance2 = MySingleton2.getInstance();
		System.out.println("instance1:" + instance1.hashCode());
		System.out.println("instance2:" + instance2.hashCode());
	} 
}

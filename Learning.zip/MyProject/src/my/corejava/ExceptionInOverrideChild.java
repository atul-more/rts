package my.corejava;

import java.io.IOException;

class ExceptionInOverrideChild extends ExceptionInOverrideParent{  
  //void msg()throws IOException {  // Overridden method CANNOT declare checked exception when superclass method does not declare an exception 
  void msg()throws ArithmeticException {  // Overridden method CAN declare unchecked exception when superclass method does not declare an exception
    System.out.println("Child");  
  }
  void exceptionMsg () { // Overridden method CAN declare NO exception when superclass method declare an exception
  //void exceptionMsg() throws Exception { // Overridden method CAN declare SUBCLASS exception (referring to Exception hierarchy) when superclass method declare an exception
  //void exceptionMsg() throws IOException { // Overridden method CAN declare exception SAME as superclass when superclass method declare an exception
	  System.out.println("Child Exception");  
  }
  
  public static void main(String args[]){  
	  ExceptionInOverrideParent p = new ExceptionInOverrideChild();  
	  p.msg();  
  }  
}  
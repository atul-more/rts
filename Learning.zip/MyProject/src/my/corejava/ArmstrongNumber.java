package my.corejava;

import java.util.Scanner;

public class ArmstrongNumber {

	/**
	 * An Armstrong number of three digits is an integer such that the sum of the cubes 
	 * of its digits is equal to the number itself. 
	 * For example, 371 is an Armstrong number since 3*3*3 + 7*7*7 + 1*1*1 = 371.
	 * 
	 * @param args
	 */
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
        int n  = sc.nextInt();
        sc.close();
        int sum = 0;
        int r;
        for(int i=n;i!=0;i=i/10)
        {
              r = i%10;
              sum = sum+(r*r*r);
        }
        if(n==sum) 
        	System.out.println("This is Armstrong number");
        else
        	System.out.println("This is not a Armstrong number");
        
        //one more function
        checkNumber(n);
	}

	private static void checkNumber(int num) {
		int temp = num;
        int sum =0;
        while(num > 0)
        {
            int rem= num % 10;
            num = num /10 ;
            sum += rem*rem*rem; 
        }
        if(temp == sum )
            System.out.println("Armstrong number");
        else
            System.out.println("Not an Armstrong number");
		
	}

}

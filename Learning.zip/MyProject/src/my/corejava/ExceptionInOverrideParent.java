/**
 * 
 */
package my.corejava;

import java.io.IOException;

/**
 * @author am0011186
 *
 */
public class ExceptionInOverrideParent {
	void msg(){System.out.println("parent");}
	//void exceptionMsg() throws IOException {System.out.println("parent exception");}
	void exceptionMsg() throws IOException {System.out.println("parent exception");}
}


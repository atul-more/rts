package my.corejava;

/**
 * super Vs this
 * 
 * 		super(5); //Calls parent class parameterized constructor.
		this(5); //Calls current class parameterized constructor. 
		this() is not allowed.
		Constructor must be called as first statement in a constructor.
		
 * @author am0011186
 *
 */
public class SuperVsThis {

	public SuperVsThis() {
		// TODO Auto-generated constructor stub
	}
	
	public SuperVsThis(StringBuilder str) {
		str.append(" Xyz");
		System.out.println(str);
	}
	
	class Parent {
		int pValue;
		
		Parent() {
			this(5);
			System.out.println("Parent class constructor called.");
		}
		Parent(int i) {
			pValue = i;
			System.out.println("Parent class constructor with param called.");
		}
	}
	
	class Child extends Parent {
		int cValue;
		
		Child() {
			//super(5); //Calls parent class parameterized constructor.
			this(5); //Calls current class parameterized constructor. this() is not allowed.
			System.out.println("Child class constructor called.");			
		}
		
		Child(int b) {
			cValue = b;
			System.out.println("Child class constructor with param called.");
		}
	}
	
	private void callThisMethod() {
		Child c = new Child();		
	}
	
	public static void main(String[] args) {
		SuperVsThis obj = new SuperVsThis();
		//this("abc"); - Constructor must be called as first statement in a constructor.
		obj.callThisMethod();
	}

}

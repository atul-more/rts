package my.corejava;

import java.util.Iterator;
import java.util.TreeSet;

/**
 * Objects that implement the Comparable interface in Java can be used as 
 * keys in a SortedMap or as elements in a SortedSet, without specifying any Comparator. 
 * 
 * @author am0011186
 *
 */
 
public class TreeSetExample {
	
    public static void main(String[] args) {
    	System.out.println("Inside main");
    	TreeSet<ComparableTest> persons = new TreeSet<ComparableTest>();
 
        persons.add(new ComparableTest("Person1", 35));
        persons.add(new ComparableTest("Person3", 20));
        persons.add(new ComparableTest("Person4", 25));
        persons.add(new ComparableTest("Person2", 21));
        
        //Print all persons.
        Iterator<ComparableTest> iter = persons.iterator();
        while(iter.hasNext()) {
            System.out.println(iter.next().toString());
        }
    }
}


package my.corejava;

import java.util.HashMap;
import java.util.Iterator;

/** This code inside static block is executed only once: 
	the first time you make an object of that class or 
	the first time you access a static member of that class 
	(even if you never make an object of that class)
*/
class Test {
	static int i;
	
	// start of static block 
    static {
        i = 10;
        System.out.println("Static block called!");
    }
    // end of static block 
    
    Test() {
    	System.out.println("Test constructor called!");
    }
}

public class HMapNullValStaticBlock {
	HMapNullValStaticBlock() {
		System.out.println("HMapNullValStaticBlock Constructor called!!");
	}
	
	public static void main(String[] args) {
		HMapNullValStaticBlock obj = new HMapNullValStaticBlock();
		
		HashMap<String,String> m = new HashMap<String,String>();

		m.put(null,null);
		m.put("1","1");
		m.put("1","2"); //Duplicate key allowed, but will overwrite earlier entry (node)
		m.put("2","2");
		m.put(null,"Abc");
		
		// Although we have two objects, static block is executed only once.
		Test t1 = new Test();
		Test t2 = new Test();
		System.out.print("Displaying hasmap:");
		System.out.println(m);
		System.out.println(Test.i);
		
	}

}

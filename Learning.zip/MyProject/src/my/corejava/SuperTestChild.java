package my.corejava;

public class SuperTestChild extends SuperTestParent{

	int speed;
	SuperTestChild() {
		super(); //is inserted by Compiler
		System.out.println("SuperTestChild Constructor!");
	}

	SuperTestChild(int speed){
		/*this();	/*This will call default constructor which should be explicitly defined 
					since we have parameterized constructor calling default one.*/
		//Compiler would insert super() here if parameterized constructor is used for obj creation
	    this.speed=speed;
	    System.out.println(this.speed);  
	  }

	  public static void main(String args[]){  
		  SuperTestChild b = new SuperTestChild(10);  
	 }  
}

package my.lambda.basics;

interface Magics {
	public String getMagician();
}

public class Application7 {
	
	public static void executeMagician(int num) {
		Magics m = new Magics() {
			
			@Override
			public String getMagician() {
				if (num == 10)
					return "TEN";
				else 
					return "ZERO";
			}
		};
		//num = 90; //even if you use 
		System.out.print("Output is: ");
		System.out.println(m.getMagician());
	}
	public static void main(String[] args) {
		Application7.executeMagician(11);	
	}
}

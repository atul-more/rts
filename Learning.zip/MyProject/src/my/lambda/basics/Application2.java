package my.lambda.basics;

public class Application2 { //becomes outer class with anonymous class use inside it

	public static void main(String[] args) {
		// Anonymous class - becomes inner class. Stored under a variable.
		Runnable runnable = new Runnable() {
			@Override
			public void run() {
				System.out.println("Welcome to Java 8 Anonymous class: Thread 1");				
			}
		};
		
		Runnable runnable2 = new Runnable() { //Anonymous classes are instantiated @ runtime.
			//Anonymous classes are replaced with lambdas (Declarative approach... not the conventional)
			//Intention is to reduce code (& expressiveness).. not reuse. 
			@Override
			public void run() {
				System.out.println("Welcome to Java 8 Anonymous class: Thread 2");				
			}
		};
		
		//Start threads
		Thread t1 = new Thread(runnable);
		Thread t2 = new Thread(runnable2);
		t1.start();
		t2.start(); //Not possible to pass variable to run(). And still you want to pass a var.
					//How would you handle this situation.
	}

}

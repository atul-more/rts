package my.lambda.basics;

import java.util.Iterator;
import java.util.List;

import com.atul.ws.ProductCatalog;
import com.atul.ws.ProductCatalogService;

public class NewImplClass {

	public static void main(String[] args) {
		
		ProductCatalogService service = new ProductCatalogService();
		ProductCatalog pd = service.getProductCatalogPort();
		List<String> str = pd.getProductCatalog();
		
		System.out.println(str);		
		
		for (Iterator<String> iterator = str.iterator(); iterator.hasNext();) {
			String string = (String) iterator.next();
			System.out.println(string);
			
		} 
	}

}

package my.lambda.basics;

public class Application4 {
	//SAM interface => from Java 8 Functional interface
	//Use of 2nd method => Makes this interface non-functional
	public interface Calculator {
		//public int calculate();
		public int calculate(int x); 
	}
	
	public static void main(String[] args) {
		//Sugared code
		Calculator c = (int num) -> {
			return num + 20;
		};
		
		//When run - interpreted to De-sugared code (byte level)
		
		System.out.println("C.calcuate = " + c.calculate(50));
	}
}
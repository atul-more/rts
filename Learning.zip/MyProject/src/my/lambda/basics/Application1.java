package my.lambda.basics;

class MusicPlayer implements Runnable {
	//SAM - Single Abstract Method (functional Interface)
	String threadVersion;

	MusicPlayer(String thr) {
		this.threadVersion = thr;
	}
	
	@Override
	public void run() {
		System.out.println("Welcome to Java 8: " + threadVersion);		
	}
}
public class Application1 {
		
	public static void main(String[] args) {
		MusicPlayer mp1 = new MusicPlayer("Thread1");
		MusicPlayer mp2 = new MusicPlayer("Thread2");
		
		Thread th1 = new Thread(mp1);
		Thread th2 = new Thread(mp2);
		
		th1.start();
		th2.start();

	}

}

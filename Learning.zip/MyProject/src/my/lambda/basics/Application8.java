package my.lambda.basics;

//You can pass Functional interface type parameter to the method as well.
@FunctionalInterface
interface Email {
	String constructEmail(String name);
}
public class Application8 {
	
	public static String getMyMailId(String name, Email email) {
		return email.constructEmail(name);
	}
	
	public static void main(String[] args) {
		//Target typing - instead of passing value, pass lambda syntax
		//Passing Lambda syntax to method (Lambda type parameter) 
		//String mailId = getMyMailId("atul.more", (name) -> name + "@techmahindra.com");
		String mailId = getMyMailId("atul.more", (name) -> {
			return name + "@techmahindra.com";	
		});
		System.out.println("Your mailId = " + mailId);
	}
}

package my.lambda.basics;

//Force the developer to follow rule of Functional Interface
@FunctionalInterface
interface MyPrediction {
	//Functional interface
	//The interface can also declare the abstract methods from the java.lang.Object class, 
	//but still the interface can be called as a Functional Interface:
	public String toString();
	public boolean equals(Object o);
	public boolean test(String capital);
}
public class Application5 {

	public static void main(String[] args) {
		MyPrediction mp = (String s) -> s.equals("NewDehli") ? true : false;

		/*MyPrediction mp = (String s) -> {
			return s.equals("NewDehli") ? true : false; 
		};*/
		//return is not required - that's the power of using Lambda with single liner
		//return is mandatory for multiliner
		
		System.out.print("The output is:");
		System.out.println(mp.test("Chennai"));
		System.out.print("The 2nd output is:");
		System.out.println(mp.test("NewDehli"));
	}
}

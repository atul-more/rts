package my.lambda.basics;

public class Application3 {

	public static void main(String[] args) {
		// Use Lambada's to code
		// pre-requisite = ONE method (abstract) required to be present.
		// methods are more then Lambda operator won't be sure of which one to override
		
		// Use Lambda operator or Arrow Token
		// Method followed by Arrow Token and then the code that perform actions
		Runnable runnable = () -> System.out.println("Welcome to Java 8 : Thread 1");
		Runnable runnable2 = () -> { 
			//Multiliner statements
			System.out.println("Welcome to Java 8 : Thread 2");
		}; //Ending with semicolon

		//Created for Anonymous (no named) class - can be created with interface or abstract class with single
		Thread th1 = new Thread(runnable);
		Thread th2 = new Thread(runnable2);
		
		th1.start();
		th2.start();
	}

}

package my.lambda.basics;

@FunctionalInterface
interface Magic {
	//public String getMagician(int num);
	public String getMagician();
}

//Use case - can use with code that has huge occurrences of use of Stream and Collections APIs 
public class Application6 {
	public void executeMagician(int num) {
		//Type Inference
		//Complier can infer type
		//Since java 1.7; ex. List<String> list = new ArrayList<>();
		//Magic m = (number) -> {
		Magic m = () -> {
			//if (number==10)
			//if (num == 10)
			if (10 == 10)
				return "TEN";
			else 
				return "ZERO";
		};
		
		num = 90; //Local variables can't be changed - they are final or effectively final
				  //Effectively => has an effect inside lambda only.	
				  //Can change the value if not used inside lambda.	
		
		System.out.print("Output is: ");
		//System.out.println(m.getMagician(num));
		System.out.println(m.getMagician());
	}
	public static void main(String[] args) {
		Application6 ap = new Application6();
		ap.executeMagician(10);
	}

}

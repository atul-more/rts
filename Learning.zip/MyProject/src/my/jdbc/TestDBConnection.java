package my.jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

public class TestDBConnection {
	
	// General JDBC connectivity to get data from Oracle DB
	private void testDBConnection() {
		String sid = "d1c1d130";
		String user = "pdts";
		String pass = "d1pwd_chngSep16";
		String port = "1524";
		String dbServerName = "zldv4088.vci.att.com";
		String url = "jdbc:oracle:thin:@" + dbServerName + ":" + port + ":" + sid;
		ResultSet rs = null;
		String query = "SELECT FTP_ID from TBL_FTP_JOB_CFG where JOB_NAME='UADM_user_test'";
		String id ="";
		Connection conn = null;
		Statement stmt = null;
		try {
			Class.forName("oracle.jdbc.OracleDriver"); //OR updated oracle.jdbc.driver.OracleDriver
			//For above statement to work - make sure to put oracle jdbc driver jar in classpath 
			conn = DriverManager.getConnection(url, user, pass);
			conn.setAutoCommit(false);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
			System.out.println("Fetching results from DB");
			if (rs.next()) {
				id = rs.getString(1);
				System.out.println(id);
			} 
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null) {
					rs.close();
				}
				if(stmt!=null) {
					stmt.close();
				}
				if(conn!=null && !conn.isClosed()) {
					conn.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}
	}
	
	//To be run through an app deployed on Server
	private void testJNDIConnection() {
		ResultSet rs = null;
		String query = "SELECT FTP_ID from TBL_FTP_JOB_CFG where JOB_NAME='UADM_user_test'";
		String id ="";
		Connection conn = null;
		Statement stmt = null;
		try {
			Context initContext = new InitialContext();
			DataSource datasource = (DataSource) initContext.lookup("java:jboss/datasources/pdtsds");
			conn = datasource.getConnection();
			System.out.println("Got DB connection");
			conn.setAutoCommit(false);
			stmt = conn.createStatement();
			rs = stmt.executeQuery(query);
			System.out.println("Fetching results from DB");
			if (rs.next()) {
				id = rs.getString(1);
				System.out.println(id);
			} 
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				if(rs!=null) {
					rs.close();
				}
				if(stmt!=null) {
					stmt.close();
				}
				if(conn!=null && !conn.isClosed()) {
					conn.close();
				}
			} catch (SQLException e) {
				e.printStackTrace();
			}
		}		
	}
	
	public static void main(String[] args) {
		System.out.println("Calling test connectivity method");
		TestDBConnection test = new TestDBConnection();
		test.testDBConnection();
		//test.testJNDIConnection();
	}

}

package tricky.programs;

/**
 * All default super class constructors are getting executed.
 * And only targeted parameterized constructor is invoked. It will in turn invoke all super class default constructors.
 */
public class Mammals {
	public Mammals() {
		System.out.println("Mammals CO");
	}
	
	public static void main(String[] args) {
		//Horse h = new Horse(); => All super class constructors are getting executed. 
		Mammals c = new Cattle("Jack");	//=> All super class constructors are getting executed. 
				//And only targeted parameterized constructor is invoked.  	
	}
}

class Cattle extends Mammals {
	public Cattle() {
		System.out.println("Cattle CO");
	} 
	public Cattle(String myCattle) {
		System.out.println("Cattle CO " + myCattle);
	}
}

class Horse extends Cattle {
	public Horse() {
		System.out.println("Horse CO");
	}
}


package tricky.programs;

public class CharInJava {

	//Displaying char type var through out obj works fine with implicit casting coming into pic.
	//When it is displayed assigning to int. Its ascii value is printed.
	public static void main(String[] args) {
		//Character ch = new Character("A"); //Compile time error with A being String
		Character ch = new Character('A');
		char c = 'A';
		int a = c; 
		System.out.println(c);
		System.out.println("Result is = " + ch + (int)ch);
		System.out.println(' ' + c); //97		
		System.out.println(' ' + a); //97
	}
	
	/**Result is 
A
Result is = 65
97
97
	**/

}

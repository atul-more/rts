package tricky.programs;

public class ParseFloat {

	public static void parse(String str) {
		//float f; //=> Local variable may not be initialized
		float f = 1.0f;
		try {
			f = Float.parseFloat(str);
			//float f = Float.parseFloat(str); //=> variable can't be resolved error
		} catch (NumberFormatException ne) {
			f = 0;
		} finally {
			System.out.println(f);
		}
	}
	public static void main(String[] args) {
		parse("Invalid");
	}

}

package tricky.programs;

public class StringSplit {

	public static void main(String[] args) {
		String s = "This is a Test";
		String[] tokens = s.split("s");
		
		/**
		 * Escape sequences available in java are:

\t - Insert a tab in the text at this point.
\b - Insert a backspace in the text at this point.
\n - Insert a newline in the text at this point.
\r - Insert a carriage return in the text at this point.
\f - Insert a formfeed in the text at this point.
\' - Insert a single quote character in the text at this point.
\" - Insert a double quote character in the text at this point.
\\ - Insert a backslash character in the text at this point.

		 */
		System.out.println(tokens.length);
	}

}

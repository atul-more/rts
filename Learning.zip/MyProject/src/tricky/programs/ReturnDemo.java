package tricky.programs;

//return; is valid and does not throw compile time error 
//any statement post that will be unreachable & will throw compile time error. 
public class ReturnDemo {

	public static void returnNothing() {
		try {
			System.out.println("Inside function");
			return;
			//System.out.println("After return");
		} finally {
			System.out.println("Inside finally");
		}
	} 
	
	public static void main(String args[]) {
		System.out.println("Inside main");
		ReturnDemo.returnNothing();
	}
	/** Result is
	Inside main
	Inside function
	Inside finally */	 
}

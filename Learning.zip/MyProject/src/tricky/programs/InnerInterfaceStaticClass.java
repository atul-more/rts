package tricky.programs;

public class InnerInterfaceStaticClass {
	interface MemI {
		public void foo();
	}
	static class Inner implements MemI {
		public void foo() {
			System.out.println("In Outer.Inner.foo()");
		}
	}
	public static void main(String[] args) {
		InnerInterfaceStaticClass.Inner in = new InnerInterfaceStaticClass.Inner();
		in.foo();
	}

}

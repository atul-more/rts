package tricky.programs;

import java.io.IOException;

/**
 * Catch block should be arranged in increasing order of Exception hierarchy like ArithmeticException first and then Exception
 * Otherwise the program throws compile time error - unreachable catch block for the latter one
 * 
 * Either (Exception | ArithmeticException e) or (ArithmeticException | Exception e) 
 * doesn't work - it says ArithmeticException is already caught by alternative Exception
 * 
 * @author am0011186
 *
 */

public class ExceptionClass {

	public static void main(String[] args) {
		int zero = 0;
		
		try {
			int result = 100/zero;
			System.out.println(result);
			throw new IOException("Test");
		} catch (ArithmeticException | IOException e) {
			System.out.println("Normal Error");
		} //unreachable catch block
		/*catch (ArithmeticException e) {
			System.out.println("Arithmetic Error");
		}*/
	}

}

package tricky.programs;

public class Foo {
	Foo() {
		System.out.println("Foo");
	}
	
	class Bar {
		Bar() {
			System.out.println("Bar");
		}
		
		public void go() {
			System.out.println("Hiiii");
		}
	}
	
	public static void main(String[] args) {
		Foo f = new Foo();
		f.makeBar();
	}
	
	void makeBar() {
		//(new Bar() {}).go();
		(new Bar()).go();
	}
}

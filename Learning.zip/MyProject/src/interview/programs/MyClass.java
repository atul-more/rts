package interview.programs;

/**
 * Singleton class means you can create only one object for the given class. 
 * You can create a singleton class by making its constructor as private, 
 * so that you can restrict the creation of the object. 
 * Provide a static method to get instance of the object, 
 * wherein you can handle the object creation inside the class only. 
 * In this example we are creating object by using static block.
 * @author am0011186
 *
 */
public class MyClass {
	 
    private static MyClass myObj;
     
    static{
        myObj = new MyClass();
        System.out.println("One time creation");
    }
     
    private MyClass(){
     
    }
     
    public static MyClass getInstance(){
        return myObj;
    }
     
    public void testMe(){
        System.out.println("Hey.... it is working!!!");
    }
     
    public static void main(String a[]){
        MyClass ms = getInstance();
        ms.testMe();
        MyClass ms1 = getInstance();
        ms1.testMe();
    }
}

package interview.programs;

/**
 * Write a program to convert decimal number to binary format using numeric operations. 
 * Below example shows how to convert decimal number to binary format using numeric operations.
 * 
 * @author am0011186
 *
 */
public class DecimalToBinary {
	 
    public void printBinaryFormat(int number){
        int binary[] = new int[25];
        int index = 0;
        while(number > 0){
            binary[index++] = number%2;
            number = number/2;
        }
        for(int i = index-1;i >= 0;i--){
            System.out.print(binary[i]);
        }
    }
     
    public int getDecimalFromBinary(int binary){
        
        int decimal = 0;
        int power = 0;
        while(true){
            if(binary == 0){
                break;
            } else {
                int tmp = binary%10;
                decimal += tmp*Math.pow(2, power);
                binary = binary/10;
                power++;
            }
        }
        return decimal;
    }
    
    public static void main(String a[]){
        DecimalToBinary dtb = new DecimalToBinary();
        dtb.printBinaryFormat(25);
        System.out.println();
        System.out.println("110 ===> " + dtb.getDecimalFromBinary(110));
        System.out.println("100110 ===> " + dtb.getDecimalFromBinary(100110));
        
    }
}

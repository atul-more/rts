/* SRS-PAR POC
 * Filename : app.js
 * Created : Ruchi D (rd6868) & Trisha D (td748n)
 * Change history : None
 * Purpose : This js page is the main controller page which routes to the respective page on selection of menu.
 */

var routerApp = angular.module('myApp', ['ui.router','angularUtils.directives.dirPagination','angularModalService','ngMessages']);

routerApp.config(function($stateProvider, $urlRouterProvider) {
    
    $urlRouterProvider.otherwise('/home');
	
	$stateProvider
        
        .state('company', {
            url: '/company',
            templateUrl: 'admin/business_units/Company.html',
			controller: 'companyCtrl'
        })
		
	.state('home', {
            url: '/home',
            templateUrl: 'home/home.html',
        })
        
        .state('center', {
            url: '/center',
            templateUrl: 'admin/business_units/center.html',
            controller: 'centerController'
        })		
});
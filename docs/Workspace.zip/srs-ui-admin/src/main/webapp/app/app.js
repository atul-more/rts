var routerApp = angular.module('myApp', ['ui.router','angularUtils.directives.dirPagination']);

routerApp.config(function($stateProvider, $urlRouterProvider) {
    
    $urlRouterProvider.otherwise('/home');
	
	$stateProvider
        
        .state('company', {
            url: '/company',
            templateUrl: 'admin/business_units/Company.html',
			controller: 'companyCtrl'
        })
		
		.state('region', {
            url: '/region',
            templateUrl: 'admin/business_units/Region.html',
			controller: 'regionCtrl'
        })
		
		.state('home', {
            url: '/home',
            templateUrl: 'home/home.html',
        })
        
        .state('center', {
            url: '/center',
            templateUrl: 'admin/business_units/center.html',
            controller: 'centerCtrl'
        })		
});
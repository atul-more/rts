/* 
     Filename : buService.js
     Created : Atul More (am5854)
     Change history : Initial copy
     Purpose : Source code for Service module for functionality to be accessed through menu Admin > Business Units.
 */
     
angular.module("myApp")
	.service("buService", ['$http', function ($http) {
		
		this.getCenterDetails = function() {
			var baseUrl = 'http://localhost:8881/admin/center/';
			var centerData = null;
			
			$http.get(baseUrl + 'list').then(function(response) {
				centerData = response.data;
			});
			
			return centerData;
		};
		
		this.close = function(result) {
		 	close(result, 500); // close, but give 500ms for bootstrap to animate
		};
	}]);
	
	
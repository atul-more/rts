/* 
     Filename : center.html
     Created : Atul More (am5854)
     Change history : Initial copy
     Purpose : Source code for UI Controller for SRS Center modification functionality (to be accessed through menu Admin > Business Units).
 */
     
angular.module("myApp")
	.controller("centerController", ['$scope', '$http', 'ModalService', function ($scope, $http, ModalService) {
		$scope.commonPath = 'http://localhost:8881/';
		
		$scope.getCenterDetails = function() {
			$http.get($scope.commonPath + 'list').then(function(response) {
				$scope.myData = response.data;
			});
		}
		
		$scope.getCenterDetails();
		
		$scope.showModalAddCenter = function() {
	        ModalService.showModal({
	            templateUrl: 'modalAddCenter.html',
	            controller: "AddCenterModalController",
	            inputs: {
	            	commonPath : $scope.commonPath
	            }
	        }).then(function(modal) {
	            modal.element.modal();
	            modal.close.then(function(result) {            	
	                if(result == 0) {
	                	$("#add-success-alert").alert();
	                    $("#add-success-alert").fadeTo(4000, 1000).slideUp(1000, function()
	                    {
	                       $("#add-success-alert").slideUp(1000);
	                    });
	                    $scope.getCenterDetails();
	                }
	                else if (result == 1)
	               	{
	                	$("#add-error-alert").alert();
	                    $("#add-error-alert").fadeTo(4000, 1000).slideUp(1000, function()
	                    {
	                       $("#add-error-alert").slideUp(1000);
	                    });
	                }
	                else if (result == 2)
	               	{
	                	$scope.alerts = [ { type: 'danger', msg: 'Duplicate Center ID! Center ID already exists. Use a different one.' } ];	
	                	//$scope.alerts.push({ type: 'danger', msg: $("#add-error-alert2")});
	                }
	                $('.modal-backdrop').remove();
	            });
	        });
	    };
	    $scope.closeAlert = function(index) {
	        $scope.alerts.splice(index, 1);
	      };
	}])
	
	.controller("AddCenterModalController", ['$scope', '$http', 'close', 'commonPath', function($scope, $http, close, commonPath) {
		$scope.close = function(result) {
		 	close(result, 500); // close, but give 500ms for bootstrap to animate
		};
		
		$scope.add = function() {
			$("#centerForm.centerId").alert();
			var center = {
		    		centerId : $scope.center.id,
		    		centerName : $scope.center.name,
		    		centerDesc : $scope.center.desc,
					companyId : $scope.center.company,
					operationHrs : $scope.center.opHrs
			};
			
		    var res = $http.post(commonPath + 'add', center);
				
			res.success(function(data, status, headers, config) {			
				close(data);
			});
			
			res.error(function(data, status, headers, config) {
				$("#gen-error-alert").alert();
	            $("#gen-error-alert").fadeTo(4000, 500).slideUp(500, function()
	            {
	               $("#gen-error-alert").slideUp(500);
	            });
	            $('.modal-backdrop').remove();
			});
		};
}]);
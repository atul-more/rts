/* 
     Filename : center.html
     Created : Atul More (am5854)
     Change history : Initial copy
     Purpose : Source code for UI Controller for SRS Center modification functionality (to be accessed through menu Admin > Business Units).
 */
     
angular.module("myApp")
	.controller("centerController", ['$scope', '$http', 'ModalService', 'buService', function ($scope, $http, ModalService, buService) {
		$scope.baseUrl = 'http://localhost:8881/admin/center/';
		
		$scope.centerData = buService.getCenterDetails();
		console.log($scope.centerData);
		$scope.showModalAddCenter = function() {
	        ModalService.showModal({
	            templateUrl: 'admin/templates/modalAddCenter.html',
	            controller: "AddCenterController",
	            inputs: {
	            	baseUrl : $scope.baseUrl
	            }
	        }).then(function(modal) {
	            modal.element.modal();
	            modal.close.then(function(result) {            	
	                if(result == 0) {
	                	$("#add-success-alert").alert();
	                    $("#add-success-alert").fadeTo(4000, 500).slideUp(500);
	                    $("#add-error-alert2").slideUp(100);
	                    $("#add-error-alert").slideUp(100);
	                    $scope.getCenterDetails();
	                }
	                else if (result == 1)
	               	{
	                	$("#add-error-alert2").slideUp(100);
	                	$("#add-error-alert").alert();
	                    $("#add-error-alert").fadeTo(4000, 500);
	                }
	                else if (result == 2)
	               	{
	                	$("#add-error-alert2").alert();
	                    $("#add-error-alert2").fadeTo(4000, 500);
	                }
	                $('.modal-backdrop').remove();
	            });
	        });
	    };
	    
	    $scope.showModalEditCenter = function(centerItem) {
	    	ModalService.showModal({
	            templateUrl: 'admin/templates/modalEditCenter.html',
	            controller: "EditCenterController",
	            inputs: {
	            	baseUrl : $scope.baseUrl,
	            	center : centerItem
	            }
	        }).then(function(modal) {
	            modal.element.modal();
	            modal.close.then(function(result) {  
	            	if(result == 0) {
	                	$("#edit-success-alert").alert();
	                    $("#edit-success-alert").fadeTo(4000, 500).slideUp(500);
	                    $("#edit-error-alert").slideUp(100);
	                    $scope.getCenterDetails();
	                }
	                else if (result == 1)
	               	{
	                	$("#edit-error-alert").alert();
	                    $("#edit-error-alert").fadeTo(4000, 500);
	                }
	                $('.modal-backdrop').remove();
	            });
	        });
	    	
	    };
	    
	    $scope.showModalDelCenter = function(inputCenterId) {
	        ModalService.showModal({
	            templateUrl: 'admin/templates/modalDeleteCenter.html',
	            controller: "DelCenterController",
	            inputs: {
	            	baseUrl : $scope.baseUrl,
	                centerId : inputCenterId
	            }
	        }).then(function(modal) {
	            modal.element.modal();
	            modal.close.then(function(result) { 
	            	if(result == 0) {
	                	$("#del-success-alert").alert();
	                    $("#del-success-alert").fadeTo(4000, 500).slideUp(500);
	                    $scope.getCenterDetails();
	                }
	                else if (result == 1) {
	                	$("#del-error-alert").alert();
	                    $("#del-error-alert").fadeTo(4000, 500);
	                }
	            	$('.modal-backdrop').remove();
	            });
	        });
	    };
	}])
	
	.controller("AddCenterController", ['$scope', '$http', 'close', 'baseUrl', function($scope, $http, close, baseUrl) {
		$scope.close = function(result) {
		 	close(result, 500); // close, but give 500ms for bootstrap to animate
		};
		
		$scope.add = function() {
			var centerForm = {
	    		centerId : $scope.centerId,
	    		centerName : $scope.centerName,
	    		companyId : $scope.companyId,
				operationHrs : $scope.operationHrs,
				centerDesc : $scope.centerDesc
			};
			
		    var res = $http.post(baseUrl + 'add', centerForm);
				
			res.success(function(data, status, headers, config) {			
				close(data);
			});
			
			res.error(function(data, status, headers, config) {
				$("#gen-error-alert").alert();
	            $("#gen-error-alert").fadeTo(4000, 500).slideUp(500);
	            $('.modal-backdrop').remove();
			});
		};		
	}])
	
	.controller("EditCenterController", ['$scope', '$http', 
                     'close', 'baseUrl', 'center', function($scope, $http, close, baseUrl, center) {
		$scope.centerId = center.centerId;
		$scope.centerName = $scope.name = center.centerName;
		$scope.companyId = $scope.comId = center.companyId;
		$scope.operationHrs = $scope.opHrs = center.operationHrs;
		$scope.centerDesc = $scope.desc = center.centerDesc;
		
		$scope.isDisabled = true;
		
		$scope.close = function(result) {
		 	close(result, 500); // close, but give 500ms for bootstrap to animate
		};
		
		$scope.edit = function() {
			var centerForm = {
	    		centerId : $scope.centerId,
	    		centerName : $scope.centerName,
	    		companyId : $scope.companyId,
				operationHrs : $scope.operationHrs,
				centerDesc : $scope.centerDesc
			};
			    
			if ($scope.centerName == center.centerName && $scope.companyId == center.companyId && 
					$scope.operationHrs == center.operationHrs && $scope.centerDesc == center.centerDesc) {
				$("#edit-warn-alert").alert();
                $("#edit-warn-alert").fadeTo(4000, 500).slideUp(500);				
				close(res);
			} else {
				var res = $http.put(baseUrl + 'update', centerForm);
				
				res.success(function(data, status, headers, config) {	
					close(data);
				});
					
				res.error(function(data, status, headers, config) {
					$("#error-alert_failure").alert();
			        $("#error-alert_failure").fadeTo(4000, 500).slideUp(500, function(){
			           $("#error-alert_failure").slideUp(500);
		            });
			        $('.modal-backdrop').remove();
				});		
			}
		};
	}])
	
	.controller("DelCenterController",['$scope','$http','close',
                   'baseUrl','centerId', function($scope, $http, close, baseUrl, centerId) {
		$scope.centerId = centerId;
		$scope.close = function(result) {
		 	close(result, 500); // close, but give 500ms for bootstrap to animate
		};
		
		$scope.deleteCenter = function() {
			var res = $http.delete(baseUrl + 'delete/' + centerId);
			res.success(function(data, status, headers, config) {
				close(data);
			});
	        
			res.error(function(data, status, headers, config) {
				$("#del-error-alert").alert();
				$("#del-error-alert").fadeTo(4000, 500).slideUp(500);
				$('.modal-backdrop').remove();
			});
		};
	
}]);
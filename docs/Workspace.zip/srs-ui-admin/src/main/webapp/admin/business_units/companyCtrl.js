/*angular.module("myApp")
	.controller("companyCtrl", ['$scope','$http', function ($scope,$http) {
		$http.get("admin/business_units/tbl_company.json").then(function(response) {
			$scope.myData = response.data.tbl_company;
		});
	}]);*/

angular.module("myApp")
	.controller("companyCtrl", ['$scope','$http', function ($scope,$http) {
		$http.get("http://localhost:8881/retrieve").then(function(response) {
		$scope.myData = response.data;
		});
}]);
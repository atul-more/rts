angular.module("myApp")
 .controller("companyCtrl", ['$scope','$http','ModalService', function ($scope, $http, ModalService) {
	
	$scope.getCompanyDetails = function() {
		$http.get("http://localhost:8881/retrieve").then(function(response) {
			$scope.myData = response.data;
		});
	}
	 
	$scope.getCompanyDetails();
	
	$scope.show = function() {
        ModalService.showModal({
            templateUrl: 'modal.html',
            controller: "ModalController"
        }).then(function(modal) {
        	modal.element.modal();
            modal.close.then(function(result) {            	
                $scope.message = "You said " + result;
                if(result == 1) {
                	$("#success-alert").alert();
                    $("#success-alert").fadeTo(4000, 500).slideUp(500, function()
                    {
                       $("#success-alert").slideUp(500);
                    });
                    $scope.getCompanyDetails();
                }
                else if (result == 0)
               	{
                	$("#error-alert").alert();
                    $("#error-alert").fadeTo(4000, 500).slideUp(500, function()
                    {
                       $("#error-alert").slideUp(500);
                    });
                }
               
                $('.modal-backdrop').remove();
               
            });
        });
    };
 }
 ])
 
 .controller("ModalController",['$scope','$http','close', function($scope, $http, close) {
	 
	 
	$scope.close = function(result) {
		close(result);
	};
	
	$scope.update = function(user) {
		errorHide = false;
		
	    var dataObj = {
	    		company_id : $scope.company.id,
	    		company_name : $scope.company.name,
	    		company_desc : $scope.company.desc,
				company_type_id : $scope.company.type_id
			};	
	    
		var res = $http.post('http://localhost:8881/add', dataObj);
			
		res.success(function(data, status, headers, config) {			
			close(data);
		});
		
		res.error(function(data, status, headers, config) {
			alert( "Failure message: " + JSON.stringify({data: data}));
		});		
		
	};
 }]);
/* SRS-PAR POC
 * Filename : companyCtrl.js
 * Created : Ruchi D (rd6868) & Trisha D (td748n)
 * Change history : None
 * Purpose : This js page is the controller page for the Company page under the menu Admin -> Business Units.
 */
     
angular.module("myApp")
 .controller("companyCtrl", ['$scope','$http','ModalService', function ($scope, $http, ModalService) {
	
	$scope.commonPath = 'http://localhost:8881/admin/company/';
	 
	$scope.getCompanyDetails = function() {
		$http.get($scope.commonPath + 'list').then(function(response) {
			$scope.myData = response.data;
		});
	}
	 
	$scope.getCompanyDetails();
	
	$scope.showModalAddCompany = function() {
        ModalService.showModal({
            templateUrl: 'modalAddCompany.html',
            controller: "AddModalController",
            inputs: {
            	commonPath : $scope.commonPath
            }
        }).then(function(modal) {
            modal.element.modal();
            modal.close.then(function(result) {            	
                if(result == 1) {
                	$("#success-alert").alert();
                    $("#success-alert").fadeTo(4000, 500).slideUp(500, function()
                    {
                       $("#success-alert").slideUp(500);
                    });
                    $scope.getCompanyDetails();
                }
                else if (result == 0)
               	{
                	$("#error-alert").alert();
                    $("#error-alert").fadeTo(4000, 500).slideUp(500, function()
                    {
                       $("#error-alert").slideUp(500);
                    });
                }
                $('.modal-backdrop').remove();
            });
        });
    };
    
    $scope.showModalEditCompany = function(x) {
    	ModalService.showModal({
            templateUrl: 'showModalEditCompany.html',
            controller: "EditModalController",
            inputs: {
            	commonPath : $scope.commonPath,
            	company_id: x.company_id,
            	company_name: x.company_name,
                company_desc: x.company_desc,
                company_type_id: x.company_type_id
            }
        }).then(function(modal) {
            modal.element.modal();
            modal.close.then(function(result) {            	
               if(result == 1) {
                	$("#success-alert_edit").alert();
                    $("#success-alert_edit").fadeTo(4000, 500).slideUp(500, function()
                    {
                       $("#success-alert_edit").slideUp(500);
                    });
                    $scope.getCompanyDetails();
                }
                else if (result == 0)
               	{
                	$("#error-alert_edit").alert();
                    $("#error-alert_edit").fadeTo(4000, 500).slideUp(500, function()
                    {
                       $("#error-alert_edit").slideUp(500);
                    });
                }
                $('.modal-backdrop').remove();
            });
        });
    	
    };
    
	$scope.showModalDeleteCompany = function(x) {
        ModalService.showModal({
            templateUrl: 'showModalDeleteCompany.html',
            controller: "DeleteModalController",
            inputs: {
            	commonPath : $scope.commonPath,
                company_id : x.company_id
            }
        }).then(function(modal) {
            modal.element.modal();
            modal.close.then(function(result) { 
            	if(result == 1) {
                	$("#success-alert_delete").alert();
                    $("#success-alert_delete").fadeTo(4000, 500).slideUp(500, function()
                    {
                       $("#success-alert_delete").slideUp(500);
                    });
                    $scope.getCompanyDetails();
                }
                else if (result == 0)
               	{
                	$("#error-alert_delete").alert();
                    $("#error-alert_delete").fadeTo(4000, 500).slideUp(500, function()
                    {
                       $("#error-alert_delete").slideUp(500);
                    });
                }
            	$('.modal-backdrop').remove();
            });
        });
    };
 }
 ])
 
 .controller("AddModalController",['$scope','$http','close','commonPath', function($scope, $http, close, commonPath) {
	
	$scope.close = function() {
		close();
	};
	
	$scope.add = function() {
		
	    var dataObj = {
	    		company_id : $scope.company.id,
	    		company_name : $scope.company.name,
	    		company_desc : $scope.company.desc,
				company_type_id : $scope.company.type_id
			};	
	    
	    var res = $http.post(commonPath + 'savecompany_json', dataObj);
			
		res.success(function(data, status, headers, config) {			
			close(data);
		});
		
		res.error(function(data, status, headers, config) {
			//console.log( "Failure message: " + JSON.stringify({data: data}));
			$("#error-alert_failure").alert();
            $("#error-alert_failure").fadeTo(4000, 500).slideUp(500, function()
            {
               $("#error-alert_failure").slideUp(500);
            });
            $('.modal-backdrop').remove();
		});		
		
	};
 }])
 
 
.controller("DeleteModalController",['$scope','$http','close','commonPath','company_id', 
	function($scope, $http, close, commonPath, company_id) {

	$scope.company_id = company_id;
	
	$scope.close = function() {
		close();
	};
	
    $scope.deleteC = function() {
		
    	var res = $http.delete(commonPath + 'deletecompanyid/' + company_id);
    	
		res.success(function(data, status, headers, config) {			
			close(data);
		});
		
		res.error(function(data, status, headers, config) {
			//console.log( "Failure message: " + JSON.stringify({data: data}));
			$("#error-alert_failure").alert();
            $("#error-alert_failure").fadeTo(4000, 500).slideUp(500, function()
            {
               $("#error-alert_failure").slideUp(500);
            });
            $('.modal-backdrop').remove();
		});
	};

}])

.controller("EditModalController",['$scope','$http','close','commonPath','company_id','company_name','company_desc','company_type_id', 
	function($scope, $http, close, commonPath, company_id, company_name, company_desc, company_type_id) {
	 
	$scope.id = company_id;
	$scope.name = $scope.org_name = company_name;
	$scope.desc = $scope.org_desc =company_desc;
	$scope.type_id = $scope.org_type_id = company_type_id;
	
	$scope.isDisabled = true;
	
	$scope.close = function() {
		close();
	};
	
	$scope.edit = function() {
		
		var dataObj = {
	    		company_id : $scope.id,
	    		company_name : $scope.name,
	    		company_desc : $scope.desc,
				company_type_id : $scope.type_id
			};	
	    
		if ($scope.org_name != $scope.name || $scope.org_desc != $scope.desc || $scope.org_type_id != $scope.type_id) {
	
			var res = $http.put(commonPath + 'updatecompany_json', dataObj);
			
			res.success(function(data, status, headers, config) {	
				close(data);
			});
			
			res.error(function(data, status, headers, config) {
				$("#error-alert_failure").alert();
	            $("#error-alert_failure").fadeTo(4000, 500).slideUp(500, function()
	            {
	               $("#error-alert_failure").slideUp(500);
	            });
	            $('.modal-backdrop').remove();
			});		
			
		} else {
			close();
		}
		
	}

}]);
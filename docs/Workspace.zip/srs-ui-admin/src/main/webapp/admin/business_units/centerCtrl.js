angular.module("myApp")
	.controller("centerCtrl", ['$scope','$http', function ($scope,$http) {
		$http.get("http://localhost:8881/list").then(function(response) {
		$scope.myData = response.data;
		});
}]);
angular.module("myApp")
	.controller("centerCtrl", ['$scope','$http', function ($scope,$http, ModalService) {
		$http.get("http://localhost:8881/list").then(function(response) {
		$scope.myData = response.data;
		});
		
		$scope.show = function() {
	        ModalService.showModal({
	            templateUrl: 'modal.html',
	            controller: "ModalController"
	        }).then(function(modal) {
	        	modal.element.modal();
	            modal.close.then(function(result) {
	                $scope.message = "You said " + result;
	            });
	        });
	    };
	}])
	.controller("ModalController", ['$scope', 'close', function ($scope,close) {
		 $scope.close = function(result) {
		 	close(result, 500); // close, but give 500ms for bootstrap to animate
		 };
}]);
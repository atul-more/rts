angular.module("myApp")
	.controller("regionCtrl", ['$scope','$http', function ($scope,$http) {
		$http.get("admin/business_units/tbl_region.json").then(function(response) {
			$scope.myData = response.data.tbl_region;
		});
	}]);
package com.att.srsbu.spec;

import org.springframework.data.jpa.repository.JpaRepository;

import com.att.srsbu.model.Company;

public interface CompanyRepository extends JpaRepository<Company, String> {

}

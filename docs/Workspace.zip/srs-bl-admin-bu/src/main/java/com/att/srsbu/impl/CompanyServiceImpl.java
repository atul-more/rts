/**
 * 
 */
package com.att.srsbu.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.att.srsbu.model.Company;
import com.att.srsbu.spec.CompanyRepository;
import com.att.srsbu.spec.CompanyService;

/**
 * @author am0011186
 *
 */
@Service
@Transactional
public class CompanyServiceImpl implements CompanyService {
	
	@Autowired
	CompanyRepository repo;
	
	/* (non-Javadoc)
	 * @see com.att.srsbu.spec.CompanyService#getComapnyList()
	 */
	@Override
	public List<Company> getCompanyList() {
		Sort sortCriteria = new Sort(Sort.Direction.ASC, "companyName");
		return repo.findAll(sortCriteria);
	}

	/* (non-Javadoc)
	 * @see com.att.srsbu.spec.CompanyService#getCompanyByCompanyId(java.lang.String)
	 */
	@Override
	public Company getCompanyByCompanyId(String companyId) {
		
		return null;
	}

	/* (non-Javadoc)
	 * @see com.att.srsbu.spec.CompanyService#addCompany(com.att.srsbu.model.Company)
	 */
	@Override
	public int addCompany(Company company) {
		
		return 0;
	}

	/* (non-Javadoc)
	 * @see com.att.srsbu.spec.CompanyService#updateCompany(com.att.srsbu.model.Company)
	 */
	@Override
	public int updateCompany(Company company) {
		
		return 0;
	}

	/* (non-Javadoc)
	 * @see com.att.srsbu.spec.CompanyService#deleteCompany(java.lang.String)
	 */
	@Override
	public int deleteCompany(String companyId) {
		
		return 0;
	}

}

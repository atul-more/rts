package com.att.srsbu.spec;

import java.util.List;

import com.att.srsbu.model.Company;

public interface CompanyService {
	List<Company> getCompanyList();
	Company getCompanyByCompanyId(String companyId);
	int addCompany(Company company);
	int updateCompany(Company company);
	int deleteCompany(String companyId);
}

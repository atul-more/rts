package com.att.srsbu.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import com.att.srsbu.util.JsonDateSerializer;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@Entity
@Table(catalog="db_Control", schema="dbo", name="tbl_company")
public class Company {
	@Id
	@Column(name="company_id")
	String companyId;
	
	@Column(name="company_name")
	String companyName;
	
	@Column(name="company_desc")
	String companyDesc;
	
	@Column(name="company_type_id")
	int companyType;
	
	@Column(name="date_created")
	Date createdDate;

	/**
	 * @return the companyId
	 */
	public String getCompanyId() {
		return companyId;
	}

	/**
	 * @param companyId the companyId to set
	 */
	public void setCompanyId(String companyId) {
		this.companyId = companyId;
	}

	/**
	 * @return the companyName
	 */
	public String getCompanyName() {
		return companyName;
	}

	/**
	 * @param companyName the companyName to set
	 */
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	/**
	 * @return the companyDesc
	 */
	public String getCompanyDesc() {
		return companyDesc;
	}

	/**
	 * @param companyDesc the companyDesc to set
	 */
	public void setCompanyDesc(String companyDesc) {
		this.companyDesc = companyDesc;
	}

	/**
	 * @return the companyType
	 */
	public int getCompanyType() {
		return companyType;
	}

	/**
	 * @param companyType the companyType to set
	 */
	public void setCompanyType(int companyType) {
		this.companyType = companyType;
	}

	/**
	 * @return the createdDate
	 */
	@JsonSerialize(using=JsonDateSerializer.class)
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}
	
}

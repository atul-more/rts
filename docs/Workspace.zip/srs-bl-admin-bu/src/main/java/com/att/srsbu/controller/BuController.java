/**
 * 
 */
package com.att.srsbu.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.att.srsbu.model.Center;
import com.att.srsbu.model.Company;
import com.att.srsbu.spec.CenterService;
import com.att.srsbu.spec.CompanyService;

/**
 * @author am0011186
 *
 */
@CrossOrigin(origins = "*")
@RestController
public class BuController {
	static int counter = 1;
	@Autowired
	CenterService cenService;
	@Autowired
	CompanyService comService;
	@Autowired
	JdbcTemplate jdbc;
	
	@RequestMapping("/")
	public ModelAndView index() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("index");
		return modelAndView;
	}
	
	@RequestMapping("/insert")
	public String addToDb() {
		jdbc.execute("insert into tbl_meta_config values ('Key', 'Value')");
		return "data inserted successfully";
	}
	
	@RequestMapping(value = "/retrieve", method = RequestMethod.GET,  produces = "application/json")
	public List<Map<String, Object>> fetchFromDb() {
		//Oracle
		//return jdbc.queryForList("select * from tbl_meta_config where cfg_name = 'Key'");
		//SQL Server
		//return jdbc.queryForList("select * from db_Control.dbo.tbl_Markets where MKTCODE = '04'");	
		return jdbc.queryForList("SELECT c.* FROM tbl_company c ORDER BY c.company_name");
	}
	
	@RequestMapping(value= "/edit/{centerId}", method = RequestMethod.GET,  produces = "application/json")
	public ModelAndView editCenter(@PathVariable String centerId) {
		ModelAndView modelAndView = new ModelAndView();
		Center center = cenService.getCenterByCenterId(centerId);
		modelAndView.setViewName("edit");
		modelAndView.addObject("center", center);
		return modelAndView;
	}
	
	@RequestMapping(value= "/admin/company/list", method = RequestMethod.GET,  produces = "application/json")
	public List<Company> getCompanyList() {
		return comService.getCompanyList();
	}
	
	@RequestMapping(value= "/admin/center/list", method = RequestMethod.GET,  produces = "application/json")
	public List<Center> getCenterList() {
		return cenService.getCenterList();
	}
	
	@RequestMapping(value= "/admin/center/add", method = RequestMethod.POST)
	public @ResponseBody int addCenter(@RequestBody Center center) {
		int result = cenService.addCenter(center);
		return result;
		//return new ResponseEntity<Center>(center, HttpStatus.OK);
	}
	
	@RequestMapping(value= "/admin/center/update", method = RequestMethod.PUT)
	public @ResponseBody int updateCenter(@RequestBody Center center) {
		int result = cenService.updateCenter(center);
		counter++;
		return result;
	}
	
	@RequestMapping(value= "/admin/center/delete/{centerId}", method = RequestMethod.DELETE)
	public @ResponseBody int deleteCenter(@PathVariable String centerId) {
		int result = cenService.deleteCenter(centerId);
		return result;
	}	
}
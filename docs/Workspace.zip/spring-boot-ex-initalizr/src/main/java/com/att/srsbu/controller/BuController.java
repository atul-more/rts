/**
 * 
 */
package com.att.srsbu.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.att.srsbu.model.Center;
import com.att.srsbu.spec.CenterService;

/**
 * @author am0011186
 *
 */
@CrossOrigin(origins = "*")
@RestController
public class BuController {

	@Autowired
	CenterService service;

	@Autowired
	JdbcTemplate jdbc;
	
	@RequestMapping("/")
	public ModelAndView index() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("index");
		return modelAndView;
	}
	
	@RequestMapping("/insert")
	public String addToDb() {
		jdbc.execute("insert into tbl_meta_config values ('Key', 'Value')");
		return "data inserted successfully";
	}
	
	@RequestMapping(value = "/retrieve", method = RequestMethod.GET,  produces = "application/json")
	public List<Map<String, Object>> fetchFromDb() {
		//Oracle
		//return jdbc.queryForList("select * from tbl_meta_config where cfg_name = 'Key'");
		//SQL Server
		//return jdbc.queryForList("select * from db_Control.dbo.tbl_Markets where MKTCODE = '04'");	
		return jdbc.queryForList("SELECT c.* FROM tbl_company c ORDER BY c.company_name");
	}
	
	@RequestMapping(value= "/list", method = RequestMethod.GET,  produces = "application/json")
	public List<Center> getCenterList() {
		return service.getCenterList();
	}
	
	@RequestMapping(value= "/list/{centerId}", method = RequestMethod.GET,  produces = "application/json")
	public ModelAndView getCenter(@PathVariable String centerId) {
		Center center = service.getCenterByCenterId(centerId);
		ModelAndView mdView = new ModelAndView();
		mdView.setViewName("display");
		mdView.addObject("center", center);
		return mdView;
	}
	
	@RequestMapping(value= "/add", method = RequestMethod.POST)
	public @ResponseBody int addCenter(@RequestBody Center center) {
		int result = 0;
		result = service.addCenter(center);
		return result;
		//return new ResponseEntity<Center>(center, HttpStatus.OK);
	}
	
	@RequestMapping(value= "/edit/{centerId}", method = RequestMethod.GET,  produces = "application/json")
	public ModelAndView editCenter(@PathVariable String centerId) {
		ModelAndView modelAndView = new ModelAndView();
		Center center = service.getCenterByCenterId(centerId);
		modelAndView.setViewName("edit");
		modelAndView.addObject("center", center);
		return modelAndView;
	}
	
	@RequestMapping(value= "/update", method = RequestMethod.POST)
	public ModelAndView updateCenter(@ModelAttribute Center center) {
		service.updateCenter(center);
		return new ModelAndView("redirect:/list/" + center.getCenterId());
	}
	
	@RequestMapping(value= "/delete", method = RequestMethod.POST)
	public ModelAndView updateCenter(@RequestParam String centerId) {
		service.deleteCenter(centerId);
		return new ModelAndView("redirect:/list");
	}
	
}
package com.att.srsbu.spec;

import java.util.List;

import com.att.srsbu.model.Center;

public interface CenterService {
	List<Center> getCenterList();
	Center getCenterByCenterId(String centerId);
	int addCenter(Center center);
	int updateCenter(Center center);
	void deleteCenter(String centerId);
}

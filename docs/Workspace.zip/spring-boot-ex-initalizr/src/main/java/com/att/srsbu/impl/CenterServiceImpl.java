package com.att.srsbu.impl;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.att.srsbu.data.CenterRepository;
import com.att.srsbu.model.Center;
import com.att.srsbu.spec.CenterService;

@Service
@Transactional
public class CenterServiceImpl implements CenterService {

	@Autowired
	CenterRepository repo;
	
	@Override
	public List<Center> getCenterList() {
		Sort sortCriteria = new Sort(Sort.Direction.ASC, "centerName");
		return repo.findAll(sortCriteria);
	}

	@Override
	public Center getCenterByCenterId(String centerId) {
		return repo.findOne(centerId);
	}

	/**
	 * Add Center entity to DB.
	 * 
	 * @param center
	 * @return int
	 */
	@Override
	public int addCenter(Center center) {
		int status = 0; //success
		
		//Add default date as sysdate
		try {
			if(center.getCreatedDate() == null) {
				Date date = new Date();
				center.setCreatedDate(date);
			}
			if(repo.exists(center.getCenterId())) {
				status = 2; //error - duplicate center id
			} else {
				repo.save(center);
			}
		} catch (Exception e) {
			status = 1; //error
			e.printStackTrace();
		}
		return status;
	}

	@Override
	public void updateCenter(Center center) {
		Date date = new Date();
		center.setCreatedDate(date);
		repo.save(center);		
	}

	@Override
	public void deleteCenter(String centerId) {
		repo.delete(centerId);
	}
}

package com.att.srsbu.impl;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.att.srsbu.data.CenterRepository;
import com.att.srsbu.model.Center;
import com.att.srsbu.spec.CenterService;

@Service
@Transactional
public class CenterServiceImpl implements CenterService {

	@Autowired
	CenterRepository repo;
	
	@Override
	public List<Center> getCenterList() {
		Sort sortCriteria = new Sort(Sort.Direction.ASC, "centerName");
		return repo.findAll(sortCriteria);
	}

	@Override
	public Center getCenterByCenterId(String centerId) {
		return repo.findOne(centerId);
	}

	@Override
	public void addCenter(Center center) {
		//Add default date as sysdate
		if(center.getCreatedDate() == null) {
			Date date = new Date();
			center.setCreatedDate(date);
		}
		repo.save(center);
	}

	@Override
	public Center editCenter(String centerId) {
		Center center = repo.findOne(centerId);
		return center;
	}
}

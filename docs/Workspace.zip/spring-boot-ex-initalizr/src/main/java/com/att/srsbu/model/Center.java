package com.att.srsbu.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import com.att.srsbu.util.JsonDateSerializer;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@Entity
//@Table(catalog="db_Control", schema="dbo", name="tbl_center")
@Table(name="tbl_center")
public class Center {
	
	@Id
	@Column(name="center_id")
	String centerId;
	
	@Column(name="center_name")
	String centerName;
	
	@Column(name="center_desc")
	String centerDesc;
	
	@Column(name="created_by")
	String createdBy;
	
	@Column(name="date_created")
	Date createdDate;
	
	@Column(name="company_id")
	String companyId;
	
	@Column(name="hrs_operation")
	String operationHrs;

	/**
	 * @return the centerId
	 */
	public String getCenterId() {
		return centerId;
	}

	/**
	 * @param centerId the centerId to set
	 */
	public void setCenterId(String centerId) {
		this.centerId = centerId;
	}

	/**
	 * @return the centerName
	 */
	public String getCenterName() {
		return centerName;
	}

	/**
	 * @param centerName the centerName to set
	 */
	public void setCenterName(String centerName) {
		this.centerName = centerName;
	}

	/**
	 * @return the centerDesc
	 */
	public String getCenterDesc() {
		return centerDesc;
	}

	/**
	 * @param centerDesc the centerDesc to set
	 */
	public void setCenterDesc(String centerDesc) {
		this.centerDesc = centerDesc;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the createdDate
	 */
	@JsonSerialize(using=JsonDateSerializer.class)
	public Date getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the createdId
	 */
	public String getCompanyId() {
		return companyId;
	}

	/**
	 * @param createdId the createdId to set
	 */
	public void setCompanyId(String createdId) {
		this.companyId = createdId;
	}

	/**
	 * @return the operationHrs
	 */
	public String getOperationHrs() {
		return operationHrs;
	}

	/**
	 * @param operationHrs the operationHrs to set
	 */
	public void setOperationHrs(String operationHrs) {
		this.operationHrs = operationHrs;
	}
}

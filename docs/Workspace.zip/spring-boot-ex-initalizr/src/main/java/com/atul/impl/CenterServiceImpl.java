package com.atul.impl;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.atul.data.CenterRepository;
import com.atul.model.Center;
import com.atul.spec.CenterService;

@Service
@Transactional
public class CenterServiceImpl implements CenterService {

	@Autowired
	CenterRepository repo;
	
	@Override
	public List<Center> getCenterList() {
		Sort sortCriteria = new Sort(Sort.Direction.ASC, "centerName");
		return repo.findAll(sortCriteria);
	}

	@Override
	public Center getCenterByCenterId(String centerId) {
		return repo.findOne(centerId);
	}

	@Override
	public void addCenter(Center center) {
		repo.save(center);
	}
}

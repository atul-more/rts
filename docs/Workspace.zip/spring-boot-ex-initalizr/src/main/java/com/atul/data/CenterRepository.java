package com.atul.data;

import org.springframework.data.jpa.repository.JpaRepository;

import com.atul.model.Center;

public interface CenterRepository extends JpaRepository<Center, String> {

}

/* 
     Filename : center.html
     Created : Atul More (am5854)
     Change history : Initial copy
     Purpose : Source code for UI Controller for SRS Center modification functionality (to be accessed through menu Admin > Business Units).
 */
     
angular.module("myApp")
	.controller("centerController", ['$scope', '$http', 'ModalService', function ($scope, $http, ModalService) {
		$scope.commonPath = 'http://localhost:8881/';
		
		$scope.getCenterDetails = function() {
			$http.get($scope.commonPath + 'list').then(function(response) {
				$scope.myData = response.data;
			});
		}
		
		$scope.getCenterDetails();
		
		$scope.showModalAddCenter = function() {
	        ModalService.showModal({
	            templateUrl: 'modalAddCenter.html',
	            controller: "AddCenterController",
	            inputs: {
	            	commonPath : $scope.commonPath
	            }
	        }).then(function(modal) {
	            modal.element.modal();
	            modal.close.then(function(result) {            	
	                if(result == 0) {
	                	$("#add-success-alert").alert();
	                    $("#add-success-alert").fadeTo(4000, 1000).slideUp(1000, function()
	                    {
	                       $("#add-success-alert").slideUp(1000);
	                    });
	                    $("#add-error-alert2").slideUp(100);
	                    $("#add-error-alert").slideUp(100);
	                    $scope.getCenterDetails();
	                }
	                else if (result == 1)
	               	{
	                	$("#add-error-alert2").slideUp(100);
	                	$("#add-error-alert").alert();
	                    $("#add-error-alert").fadeTo(4000, 1000);
	                }
	                else if (result == 2)
	               	{
	                	$("#add-error-alert2").alert();
	                    $("#add-error-alert2").fadeTo(4000, 1000);
	                }
	                $('.modal-backdrop').remove();
	            });
	        });
	    };
	    
	    $scope.showModalEditCenter = function(x) {
	    	ModalService.showModal({
	            templateUrl: 'modalEditCenter.html',
	            controller: "EditCenterController",
	            inputs: {
	            	commonPath : $scope.commonPath,
	            	centerId: x.centerId,
	            	centerName: x.centerName,
	            	companyId: x.companyId,
	            	operationHrs: x.operationHrs,
	            	centerDesc: x.centerDesc
	            }
	        }).then(function(modal) {
	            modal.element.modal();
	            modal.close.then(function(result) {            	
	               if(result == 1) {
	                	$("#edit-success-alert").alert();
	                    $("#edit-success-alert").fadeTo(4000, 500).slideUp(500, function()
	                    {
	                       $("#edit-success-alert").slideUp(500);
	                    });
	                    $scope.getCompanyDetails();
	                }
	                else if (result == 0)
	               	{
	                	$("#edit-error-alert").alert();
	                    $("#edit-error-alert").fadeTo(4000, 500).slideUp(500, function()
	                    {
	                       $("#edit-error-alert").slideUp(500);
	                    });
	                }
	                $('.modal-backdrop').remove();
	            });
	        });
	    	
	    };
	}])
	
	.controller("AddCenterController", ['$scope', '$http', 'close', 'commonPath', function($scope, $http, close, commonPath) {
		$scope.close = function(result) {
		 	close(result, 500); // close, but give 500ms for bootstrap to animate
		};
		
		$scope.add = function() {
			$("#centerForm.centerId").alert();
			var center = {
		    		centerId : $scope.centerId,
		    		centerName : $scope.centerName,
		    		companyId : $scope.centerCompany,
					operationHrs : $scope.operationHrs,
					centerDesc : $scope.centerDesc
			};
			
		    var res = $http.post(commonPath + 'add', center);
				
			res.success(function(data, status, headers, config) {			
				close(data);
			});
			
			res.error(function(data, status, headers, config) {
				$("#gen-error-alert").alert();
	            $("#gen-error-alert").fadeTo(4000, 500).slideUp(500, function()
	            {
	               $("#gen-error-alert").slideUp(500);
	            });
	            $('.modal-backdrop').remove();
			});
		};		
	}])
	
	.controller("EditCenterController", ['$scope', '$http', 'close', 'commonPath', 'centerId', 
                   'centerName', 'companyId', 'operationHrs', 'centerDesc', function($scope, $http, close, commonPath, 
                		   centerId, centerName, companyId, operationHrs, centerDesc) {
		$scope.centerId = centerId;
		$scope.centerName = $scope.name = centerName;
		$scope.companyId = $scope.comId = companyId;
		$scope.operationHrs = $scope.opHrs = operationHrs;
		$scope.centerDesc = $scope.desc = centerDesc;
		
		$scope.isDisabled = true;
		
		$scope.close = function(result) {
		 	close(result, 500); // close, but give 500ms for bootstrap to animate
		};
		
		$scope.edit = function() {
			var center = {
	    		centerId : $scope.centerId,
	    		centerName : $scope.centerName,
	    		companyId : $scope.centerCompany,
				operationHrs : $scope.operationHrs,
				centerDesc : $scope.centerDesc
			};
			    
			if ($scope.centerName != $scope.name || $scope.centerCompany != $scope.comId || $scope.operationHrs != $scope.opHrs
					|| $scope.centerDesc != $scope.desc) {
				var res = $http.put(commonPath + 'update', center);
				
				res.success(function(data, status, headers, config) {	
					close(data);
				});
					
				res.error(function(data, status, headers, config) {
					$("#error-alert_failure").alert();
			        $("#error-alert_failure").fadeTo(4000, 500).slideUp(500, function(){
			           $("#error-alert_failure").slideUp(500);
		            });
			        $('.modal-backdrop').remove();
				});		
					
			} else {
				close(res);
			}
		};
}]);
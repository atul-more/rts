angular.module("myApp")
	.controller("centerCtrl", ['$scope','$http', function ($scope,$http) {
		$http.get("http://localhost:8881/list").then(function(response) {
		$scope.myData = response.data;
		});
		
		$scope.update = function(center) {
			errorHide = false;
			
		    var dataObj = {
		    		centerId : $scope.center.id,
		    		centerName : $scope.center.name,
		    		centerDesc : $scope.center.desc,
					companyId : $scope.center.company,
					operationHrs : $scope.center.opHrs 
					
				};	
		    
			var res = $http.post('http://localhost:8881/add', dataObj);
				
			res.success(function(data, status, headers, config) {			
				close(data);
			});
			
			res.error(function(data, status, headers, config) {
				alert( "Failure message: " + JSON.stringify({data: data}));
			});
}]);
package com.att.srsbu.data;

import org.springframework.data.jpa.repository.JpaRepository;

import com.att.srsbu.model.Center;

public interface CenterRepository extends JpaRepository<Center, String> {

}

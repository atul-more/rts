package com.atul.spec;

import java.util.List;

import com.atul.model.Center;

public interface CenterService {
	List<Center> getCenterList();
	Center getCenterByCenterId(String centerId);
	void addCenter(Center center);
}

/**
 * 
 */
package com.atul;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.atul.data.CenterRepository;
import com.atul.impl.CenterServiceImpl;
import com.atul.model.Center;
import com.atul.spec.CenterService;

/**
 * @author am0011186
 *
 */
@CrossOrigin(origins = "*")
@RestController
public class MainController {

	@RequestMapping("/")
	public ModelAndView index() {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("index");
		return modelAndView;
	}
	 
	@RequestMapping(value="/save",method = RequestMethod.POST)
	public ModelAndView save(@ModelAttribute User user) {
		 ModelAndView modelAndView = new ModelAndView();
		 modelAndView.setViewName("user-data");
		 modelAndView.addObject("user", user);
		 return modelAndView;
	}
	
	@Autowired
	JdbcTemplate jdbc;
	
	@Autowired
	CenterService service;
	
	@RequestMapping("/insert")
	public String addToDb() {
		jdbc.execute("insert into tbl_meta_config values ('Key', 'Value')");
		return "data inserted successfully";
	}
	
	@RequestMapping(value = "/retrieve", method = RequestMethod.GET,  produces = "application/json")
	public List<Map<String, Object>> fetchFromDb() {
		//Oracle
		//return jdbc.queryForList("select * from tbl_meta_config where cfg_name = 'Key'");
		//SQL Server
		//return jdbc.queryForList("select * from db_Control.dbo.tbl_Markets where MKTCODE = '04'");	
		return jdbc.queryForList("SELECT c.* FROM dbo.tbl_company c ORDER BY c.company_name");
	}
	
	@RequestMapping(value= "/list", method = RequestMethod.GET,  produces = "application/json")
	public List<Center> getCenterList() {
		return service.getCenterList();
	}
	
	@RequestMapping(value= "/list/{centerId}", method = RequestMethod.GET,  produces = "application/json")
	public Center getCenter(@PathVariable String centerId, Center center) {
		return service.getCenterByCenterId(centerId);
	}
	
	@RequestMapping(value= "/add", method = RequestMethod.POST)
	@ResponseBody
	public ModelAndView addCenter(@ModelAttribute Center center) {
		service.addCenter(center);
		//return new ResponseEntity<Center>(center, HttpStatus.OK);
		return new ModelAndView("redirect:/list/" + center.getCenterId());
	}
}

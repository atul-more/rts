package demo;

public class Constants {
	 public static final String LOCATION_HANOI = "HaNoi";    
	   public static final String LOCATION_TOKYO = "Tokyo";
	   public static final String LOCATION_CHICAGO = "Chicago";
	    
	    
	  
	   public static final String WEATHER_RAIN ="rain";
	    
	  
	   public static final String WEATHER_SUNNY ="sunny";
	 
}

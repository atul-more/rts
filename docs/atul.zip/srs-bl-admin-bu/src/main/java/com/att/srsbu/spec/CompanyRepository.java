/**
 * @author : Ruchi D (rd6868) & Trisha D (td748n)
 * Purpose : Interface for Spring Data JPA to store and retrieve SRS Company data.
 * 
 * Change history - 
 * 		Date 				:	Change description
 * 		30th June, 2017 	:	Initial copy
 */

package com.att.srsbu.spec;

import org.springframework.data.jpa.repository.JpaRepository;

import com.att.srsbu.model.Company;

public interface CompanyRepository extends JpaRepository<Company, String> {

}

/** 
 * @author : Ruchi D (rd6868) & Trisha D (td748n)
 * Purpose : Interface for Modify SRS Company related functions.
 * 
 * Change history - 
 * 		Date 				:	Change description
 * 		30th June, 2017 	:	Initial copy
 */

package com.att.srsbu.spec;

import java.util.List;

import com.att.srsbu.model.Company;

public interface CompanyService {

	List<Company> getCompanyList();
	int addCompany(Company company);
	int updateCompany(Company company);
	int deleteCompany(String companyId);
	
}

/** 
 * @author : Atul M(am5854)
 * Purpose : Interface for Modify SRS Center related functions.
 * 
 * Change history - 
 * 		Date 				:	Change description
 * 		30th June, 2017 	:	Initial copy
 */

package com.att.srsbu.spec;

import java.util.List;

import com.att.srsbu.model.Center;

public interface CenterService {
	List<Center> getCenterList();
	int addCenter(Center center);
	int updateCenter(Center center);
	int deleteCenter(String centerId);
}

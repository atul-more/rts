/** 
 * @author : Ruchi D (rd6868) & Trisha D (td748n)
 * Purpose : Implementation of Modify SRS Company related functions.
 * 
 * Change history - 
 * 		Date 				:	Change description
 * 		30th June, 2017 	:	Initial copy
 */

package com.att.srsbu.impl;

import java.util.Date;
import java.util.List;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.att.srsbu.model.Company;
import com.att.srsbu.spec.CompanyRepository;
import com.att.srsbu.spec.CompanyService;

@Service
@Transactional
public class CompanyServiceImpl implements CompanyService {

	@Autowired
	CompanyRepository repo;
	
	@Override
	public List<Company> getCompanyList() {
		Sort sortCriteria = new Sort(Sort.Direction.ASC, "companyName");
		return repo.findAll(sortCriteria);
	}
	
	@Override
	public int addCompany(Company company) {
		int status = 0;
		try {
			if(company.getCreatedDate() == null) {
				Date date = new Date();
				company.setCreatedDate(date);
			}
			if(repo.exists(company.getCompanyId())) {
				status = 2;
			} else {
				repo.save(company);
			}
		} catch (Exception e) {
			status = 1;
			e.printStackTrace();
		}
		return status;
	}

	@Override
	public int updateCompany(Company company) {
		int status = 0;
		try {
			Date date = new Date();
			company.setCreatedDate(date);
			repo.save(company);
		} catch (Exception e) {
			status = 1;
			e.printStackTrace();
		}
		return status;
	}
	
	@Override
	public int deleteCompany(String companyId) {
		int status = 0;
		try {	
			repo.delete(companyId);
		} catch (Exception e) {
			status = 1;
			e.printStackTrace();
		}
		return status;
	}
}

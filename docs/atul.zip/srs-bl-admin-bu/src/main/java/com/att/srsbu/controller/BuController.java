/** 
 * @author : Atul M(am5854) & Ruchi D (rd6868) & Trisha D (td748n)
 * Purpose : This java file is the main controller file of Company service.
 * 
 * Change history - 
 * 		Date 				:	Change description
 * 		30th June, 2017 	:	Initial copy
 */

package com.att.srsbu.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.att.srsbu.model.Center;
import com.att.srsbu.model.Company;
import com.att.srsbu.spec.CenterService;
import com.att.srsbu.spec.CompanyService;

/**
 * @author am0011186
 *
 */
@CrossOrigin(origins = "*")
@RestController
public class BuController {
	static int counter = 1;
	@Autowired
	CenterService cenService;
	@Autowired
	CompanyService comService;
	@Autowired
	JdbcTemplate jdbc;
	
	@RequestMapping(value= "/admin/company/list", method = RequestMethod.GET,  produces = "application/json")
	public List<Company> getCompanyList() {
		return comService.getCompanyList();
	}
	
	@RequestMapping(value= "/admin/company/add", method = RequestMethod.POST)
	public @ResponseBody int addCompany(@RequestBody Company company) {
		int result = comService.addCompany(company);
		return result;
	}
	
	@RequestMapping(value= "/admin/company/update", method = RequestMethod.PUT)
	public @ResponseBody int updateCompany(@RequestBody Company company) {
		int result = comService.updateCompany(company);
		return result;
	}
	
	@RequestMapping(value= "/admin/company/delete/{companyId}", method = RequestMethod.DELETE)
	public @ResponseBody int deleteCompany(@PathVariable("companyId") String companyId) {
		int result = comService.deleteCompany(companyId);
		return result;
	}	

	@RequestMapping(value= "/admin/center/list", method = RequestMethod.GET,  produces = "application/json")
	public List<Center> getCenterList() {
		return cenService.getCenterList();
	}
	
	@RequestMapping(value= "/admin/center/add", method = RequestMethod.POST)
	public @ResponseBody int addCenter(@RequestBody Center center) {
		int result = cenService.addCenter(center);
		return result;
	}
	
	@RequestMapping(value= "/admin/center/update", method = RequestMethod.PUT)
	public @ResponseBody int updateCenter(@RequestBody Center center) {
		int result = cenService.updateCenter(center);
		counter++;
		return result;
	}
	
	@RequestMapping(value= "/admin/center/delete/{centerId}", method = RequestMethod.DELETE)
	public @ResponseBody int deleteCenter(@PathVariable String centerId) {
		int result = cenService.deleteCenter(centerId);
		return result;
	}	
}
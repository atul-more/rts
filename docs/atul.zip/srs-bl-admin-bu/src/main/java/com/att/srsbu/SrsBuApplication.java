/**
 * @author : Atul M(am5854) & Ruchi D (rd6868) & Trisha D (td748n)
 * Purpose : This java file contains the code for starting the Spring application.
 * 
 * Change history -
 * 		Date 				:	Change description
 * 		30th June, 2017 	:	Initial copy
 */

package com.att.srsbu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

//The EnableDiscoveryClient activates the Netflix Eureka DiscoveryClient implementation.
@EnableDiscoveryClient
@SpringBootApplication
public class SrsBuApplication {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		SpringApplication.run(SrsBuApplication.class, args);
	}

}

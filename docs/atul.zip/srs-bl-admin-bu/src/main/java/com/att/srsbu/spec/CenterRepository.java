/** 
 * @author : Atul M(am5854)
 * Purpose : Interface for Spring Data JPA to store and retrieve SRS Center data.
 * 
 * Change history - 
 * 		Date 				:	Change description
 * 		30th June, 2017 	:	Initial copy
 */

package com.att.srsbu.spec;

import org.springframework.data.jpa.repository.JpaRepository;

import com.att.srsbu.model.Center;

public interface CenterRepository extends JpaRepository<Center, String> {

}

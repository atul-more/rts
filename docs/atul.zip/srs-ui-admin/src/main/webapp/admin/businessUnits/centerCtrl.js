/*
 * 	Author: Atul More (am5854)
 *	Purpose: Source code for UI Controller for SRS Center modification functionality (to be accessed through menu Admin > Business Units).
 *
 *	Change history -
 *
 *		Date 				:	Change description
 *		30th June, 2017 	:	Initial copy
 */
     
routerApp
	.controller("centerController", ['$scope', 'ModalService', 'buService', function ($scope, ModalService, buService) {
		var urlMap = null;
		
		//Get the URL Mapping from service
		$scope.getUrlMap = function() {
			urlMap = buService.getUrlMap();
		}
		$scope.getUrlMap();
		
		//Load list of Centers
		$scope.getCenterList = function () {
			buService.httpGetObjList(urlMap.centerListUrl)
			.then(function(respose) {
				$scope.centerData = respose.data;
			}, function(error) {
				console.log(error.statusText);
			});
		}
		
		$scope.getCenterList();
		
		//Load company list as well for SELECT control
		$scope.getCompanyList = function () {
			buService.httpGetObjList(urlMap.companyListUrl)
			.then(function(respose) {
				$scope.companyData = respose.data;
			}, function(error) {
				console.log(error.statusText);
			});
		}
		
		$scope.getCompanyList();
		
		//Close function for modal pop-ups
		$scope.close = function(result) {
		 	close(result, 500); // close, but give 500ms for bootstrap to animate
		}
		
		$scope.showModalAddCenter = function() {
	        ModalService.showModal({
	            templateUrl: urlMap.addCenterTemplate,
	            controller: "AddCenterController",
	            inputs: {
	            	url : urlMap.addCenterUrl,
	            	companyData: $scope.companyData
	            }
	        }).then(function(modal) {
	        	modal.element.modal();
	            modal.close.then(function(result) {
	            	if(result == 0) {
	                	$("#add-success-alert").alert();
	                    $("#add-success-alert").fadeTo(4000, 500).slideUp(500);
	                    $("#add-error-alert2").slideUp(100);
	                    $("#add-error-alert").slideUp(100);
	                    $scope.getCenterList();
	                }
	                else if (result == 1)
	               	{
	                	$("#add-error-alert2").slideUp(100);
	                	$("#add-error-alert").alert();
	                    $("#add-error-alert").fadeTo(4000, 500);
	                }
	                else if (result == 2)
	               	{
	                	$("#add-error-alert2").alert();
	                    $("#add-error-alert2").fadeTo(4000, 500);
	                }
	                $('.modal-backdrop').remove();
	            });
	        });
	    }
	    
	    $scope.showModalEditCenter = function(centerItem) {
	    	ModalService.showModal({
	            templateUrl: urlMap.editCenterTemplate,
	            controller: "EditCenterController",
	            inputs: {
	            	url : urlMap.editCenterUrl,
	            	center : centerItem,
	            	companyData: $scope.companyData
	            }
	        }).then(function(modal) {
	            modal.element.modal();
	            modal.close.then(function(result) {  
	            	if(result == 0) {
	                	$("#edit-success-alert").alert();
	                    $("#edit-success-alert").fadeTo(4000, 500).slideUp(500);
	                    $("#edit-error-alert").slideUp(100);
	                    $scope.getCenterList();
	                }
	                else if (result == 1)
	               	{
	                	$("#edit-error-alert").alert();
	                    $("#edit-error-alert").fadeTo(4000, 500);
	                }
	                $('.modal-backdrop').remove();
	            });
	        });
	    	
	    }
	    
	    $scope.showModalDelCenter = function(inputCenterId) {
	        ModalService.showModal({
	            templateUrl: urlMap.delCenterTemplate,
	            controller: "DelCenterController",
	            inputs: {
	            	baseUrl : urlMap.deleteCenterUrl,
	                centerId : inputCenterId
	            }
	        }).then(function(modal) {
	            modal.element.modal();
	            modal.close.then(function(result) { 
	            	if(result == 0) {
	                	$("#del-success-alert").alert();
	                    $("#del-success-alert").fadeTo(4000, 500).slideUp(500);
	                    $scope.getCenterList();
	                }
	                else if (result == 1) {
	                	$("#del-error-alert").alert();
	                    $("#del-error-alert").fadeTo(4000, 500);
	                }
	            	$('.modal-backdrop').remove();
	            });
	        });
	    }
	}])
	
	.controller("AddCenterController", ['$scope', 'buService', 'close', 'url', 'companyData', 
	                                    function($scope, buService, close, url, companyData) {
		//Make company data available for view through this model.
		$scope.companyData = companyData;
		
		$scope.add = function() {
			var centerForm = {
		    	centerId : $scope.centerId,
		    	centerName : $scope.centerName,
		    	companyId : $scope.companyId,
				operationHrs : $scope.operationHrs,
				centerDesc : $scope.centerDesc
			};
			
			buService.httpPostObj(url, centerForm)
			.then(function(response) {
				close(response.data);
			}, function(error) {
				console.log(error.statusText);
				$("#gen-error-alert").alert();
	            $("#gen-error-alert").fadeTo(4000, 500).slideUp(500);
	            $('.modal-backdrop').remove();
			});
		}
	}])
	
	.controller("EditCenterController", ['$scope', 'buService',
                     'close', 'url', 'center', 'companyData', function($scope, buService, close, url, center, companyData) {
		//Make company data available for view through this model.
		$scope.companyData = companyData;
		
		$scope.centerId = center.centerId;
		$scope.centerName = $scope.name = center.centerName;
		$scope.companyId = $scope.comId = center.companyId;
		$scope.operationHrs = $scope.opHrs = center.operationHrs;
		$scope.centerDesc = $scope.desc = center.centerDesc;
		
		$scope.isDisabled = true;
		
		$scope.edit = function() {
			var centerForm = {
	    		centerId : $scope.centerId,
	    		centerName : $scope.centerName,
	    		companyId : $scope.companyId,
				operationHrs : $scope.operationHrs,
				centerDesc : $scope.centerDesc
			};
			    
			if ($scope.centerName == center.centerName && $scope.companyId == center.companyId && 
					$scope.operationHrs == center.operationHrs && $scope.centerDesc == center.centerDesc) {
				$("#edit-warn-alert").alert();
                $("#edit-warn-alert").fadeTo(4000, 500).slideUp(500);
                close(100); //100 closure code is not handled. It will just close window without adding any additional alert.
			} else {
				buService.httpPutObj(url, centerForm)
				.then(function(response) {
					close(response.data);
				}, function(error) {
					console.log(error.statusText);
					$("#error-alert_failure").alert();
			        $("#error-alert_failure").fadeTo(4000, 500).slideUp(500, function(){
			           $("#error-alert_failure").slideUp(500);
		            });
			        $('.modal-backdrop').remove();
				});
			}
		}
	}])
	
	.controller("DelCenterController",['$scope','buService','close',
                   'baseUrl','centerId', function($scope, buService, close, baseUrl, centerId) {
		$scope.centerId = centerId;
		
		$scope.deleteCenter = function() {
			buService.httpDeleteObj(baseUrl + centerId)
			.then(function(response) {
				close(response.data);
			}, function(error) {
				console.log(error.statusText);
				$("#del-error-alert").alert();
				$("#del-error-alert").fadeTo(4000, 500).slideUp(500);
				$('.modal-backdrop').remove();
			});
		}	
}]);
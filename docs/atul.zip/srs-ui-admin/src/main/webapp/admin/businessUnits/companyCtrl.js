/*
 * 	Author: Ruchi D (rd6868) & Trisha D (td748n)
 *	Purpose: This js page is the controller page for the Company page under the menu Admin -> Business Units.
 *
 *	Change history -
 *
 *		Date 				:	Change description
 *		30th June, 2017 	:	Initial copy
 */
     
routerApp
 .controller("companyController", ['$scope', '$http', 'ModalService', 'buService', function ($scope, $http, ModalService, buService) {
	 var urlMap = null;
		
	//Get the URL Mapping from service
	$scope.getUrlMap = function() {
		urlMap = buService.getUrlMap();
	}
	$scope.getUrlMap();
	
	$scope.baseUrl = urlMap.companyListUrl;
	 
	$scope.getCompanyDetails = function() {
		$http.get($scope.baseUrl).then(function(response) {
			$scope.companyRecords = response.data;
		});
	}
	 
	$scope.getCompanyDetails();
	
	$scope.showModalAddCompany = function() {
        ModalService.showModal({
            templateUrl: 'admin/templates/modalAddCompany.html',
            controller: "AddCompanyController",
            inputs: {
            	baseUrl : $scope.baseUrl
            }
        }).then(function(modal) {
            modal.element.modal();
            modal.close.then(function(result) {
            	if(result==0) {
            		$("#add-success-alert").alert();
                    $("#add-success-alert").fadeTo(4000, 500).slideUp(500, function()
                    {
                       $("#add-success-alert").slideUp(500);
                    });
                    $scope.getCompanyDetails();
            	}
            	else if(result==1) {
            		$("#add-error-alert").alert();
                    $("#add-error-alert").fadeTo(4000, 500).slideUp(500, function()
                    {
                       $("#add-error-alert").slideUp(500);
                    });
            	}
            	else if(result==2) {
            		$("#add-error-alert2").alert();
                    $("#add-error-alert2").fadeTo(4000, 500).slideUp(500, function()
                    {
                       $("#add-error-alert2").slideUp(500);
                    });
            	}
                $('.modal-backdrop').remove();
            });
        });
    };
    
    $scope.showModalEditCompany = function(x) {
    	ModalService.showModal({
            templateUrl: 'admin/templates/modalEditCompany.html',
            controller: "EditCompanyController",
            inputs: {
            	baseUrl : $scope.baseUrl,
            	companyId: x.companyId,
            	companyName: x.companyName,
                companyDesc: x.companyDesc,
                companyTypeId: x.companyTypeId
            }
        }).then(function(modal) {
            modal.element.modal();
            modal.close.then(function(result) {    
            	if(result==0) {
            		$("#edit-success-alert").alert();
                    $("#edit-success-alert").fadeTo(4000, 500).slideUp(500, function()
                    {
                       $("#edit-success-alert").slideUp(500);
                    });
                    $scope.getCompanyDetails();
            	}
            	else if(result==1) {
            		$("#edit-error-alert").alert();
                    $("#edit-error-alert").fadeTo(4000, 500).slideUp(500, function()
                    {
                       $("#edit-error-alert").slideUp(500);
                    });
            	}
                $('.modal-backdrop').remove();
            });
        });
    };
    
	$scope.showModalDelCompany = function(inputCompanyId) {
        ModalService.showModal({
            templateUrl: 'admin/templates/modalDelCompany.html',
            controller: "DelCompanyController",
            inputs: {
            	baseUrl : $scope.baseUrl,
            	companyId : inputCompanyId
            }
        }).then(function(modal) {
            modal.element.modal();
            modal.close.then(function(result) { 
            	if(result==0) {
            		$("#del-success-alert").alert();
                    $("#del-success-alert").fadeTo(4000, 500).slideUp(500, function()
                    {
                       $("#del-success-alert").slideUp(500);
                    });
                    $scope.getCompanyDetails();
            	}
            	else if(result==1) {
            		$("#del-error-alert").alert();
                    $("#del-error-alert").fadeTo(4000, 500).slideUp(500, function()
                    {
                       $("#del-error-alert").slideUp(500);
                    });
            	}
            	$('.modal-backdrop').remove();
            });
        });
    };
 }
 ])
 
 .controller("AddCompanyController",['$scope','$http','close','baseUrl', function($scope, $http, close, baseUrl) {
	
	$scope.close = function() {
		close();
	};
	
	$scope.addCompany = function() {
		
	    var companyData = {
	    		companyId : $scope.company.id,
	    		companyName : $scope.company.name,
	    		companyDesc : $scope.company.desc,
				companyTypeId : $scope.company.typeId
			};	
	    
	    var res = $http.post(baseUrl + 'add', companyData);
			
		res.success(function(data, status, headers, config) {			
			close(data);
		});
		
		res.error(function(data, status, headers, config) {
			//console.log( "Failure message: " + JSON.stringify({data: data}));
			$("#failure-error-alert").alert();
            $("#failure-error-alert").fadeTo(4000, 500).slideUp(500, function()
            {
               $("#failure-error-alert").slideUp(500);
            });
            $('.modal-backdrop').remove();
		});		
	};
 }])
 
.controller("EditCompanyController",['$scope','$http','close','baseUrl','companyId','companyName','companyDesc','companyTypeId', 
	function($scope, $http, close, baseUrl, companyId, companyName, companyDesc, companyTypeId) {
	 
	$scope.id = companyId;
	$scope.name = $scope.orgName = companyName;
	$scope.desc = $scope.orgDesc =companyDesc;
	$scope.typeId = $scope.orgTypeId = companyTypeId;
	
	$scope.isDisabled = true;
	
	$scope.close = function() {
		close();
	};
	
	$scope.editCompany = function() {
		
		var companyData = {
				companyId : $scope.id,
				companyName : $scope.name,
				companyDesc : $scope.desc,
				companyTypeId : $scope.typeId
			};	
	    
		if ($scope.orgName != $scope.name || $scope.orgDesc != $scope.desc || $scope.orgTypeId != $scope.typeId) {
	
			var res = $http.put(baseUrl + 'update', companyData);
			
			res.success(function(data, status, headers, config) {	
				close(data);
			});
			
			res.error(function(data, status, headers, config) {
				//console.log( "Failure message: " + JSON.stringify({data: data}));
				$("#failure-error-alert").alert();
	            $("#failure-error-alert").fadeTo(4000, 500).slideUp(500, function()
	            {
	               $("#failure-error-alert").slideUp(500);
	            });
	            $('.modal-backdrop').remove();
			});		
			
		} else {
			$("#edit-warn-alert").alert();
            $("#edit-warn-alert").fadeTo(4000, 500).slideUp(500, function()
            {
               $("#edit-warn-alert").slideUp(500);
            });
            $('.modal-backdrop').remove();
			close();
		}
	}
}])

 
.controller("DelCompanyController",['$scope','$http','close','baseUrl','companyId', 
	function($scope, $http, close, baseUrl, companyId) {

	$scope.companyId = companyId;
	
	$scope.close = function() {
		close();
	};
	
    $scope.deleteCompany = function() {
		
    	var res = $http.delete(baseUrl + 'delete/' + companyId);
    	
		res.success(function(data, status, headers, config) {			
			close(data);
		});
		
		res.error(function(data, status, headers, config) {
			//console.log( "Failure message: " + JSON.stringify({data: data}));
			$("#failure-error-alert").alert();
            $("#failure-error-alert").fadeTo(4000, 500).slideUp(500, function()
            {
               $("#failure-error-alert").slideUp(500);
            });
            $('.modal-backdrop').remove();
		});
	};

}]);
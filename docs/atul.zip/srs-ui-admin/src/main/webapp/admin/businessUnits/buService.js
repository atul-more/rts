/*
 * 	Author: Atul More (am5854)
 *	Purpose: Source code for Service module for functionality to be accessed through menu Admin > Business Units.
 *
 *	Change history -
 *
 *		Date 				:	Change description
 *		30th June, 2017 	:	Initial copy
 */

routerApp.factory("buService", ['$http', '$q', function($http, $q) {
	return {
		
		getUrlMap: function() {
			var baseCenterUrl = 'http://localhost:8881/admin/center/';
			var baseCompanyUrl = 'http://localhost:8881/admin/company/'
			var urlMap = {
					centerListUrl: baseCenterUrl + 'list',
					companyListUrl: baseCompanyUrl + 'list',
					addCenterUrl: baseCenterUrl + 'add',
					editCenterUrl: baseCenterUrl + 'update',
					deleteCenterUrl: baseCenterUrl + 'delete/', //will append centerId to this URL 
					addCenterTemplate: 'admin/templates/modalAddCenter.html',
					editCenterTemplate: 'admin/templates/modalEditCenter.html',
					delCenterTemplate: 'admin/templates/modalDeleteCenter.html',
			};
			
			return urlMap;
		},
	
		httpGetObjList: function (url) {
			var deferred = $q.defer();
			return $http.get(url)
				.then(function(response) {
					deferred.resolve(response);
					return response;
			});
		},
		
		httpPostObj: function (url, obj) {
			var deferred = $q.defer();
			return $http.post(url, obj)
				.then(function(response) {
					deferred.resolve(response);
					return response;
			});
		},
		
		httpPutObj: function (url, obj) {
			var deferred = $q.defer();
			return $http.put(url, obj)
				.then(function(response) {
					deferred.resolve(response);
					return response;
			});
		},
		
		httpDeleteObj: function (url, obj) {
			var deferred = $q.defer();
			return $http.delete(url)
				.then(function(response) {
					deferred.resolve(response);
					return response;
			});
		}
	}
}]);
	
	
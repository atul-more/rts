/*
 * 	Author: Ruchi D (rd6868) & Trisha D (td748n)
 *	Purpose: This js page is the main controller page which routes to the respective page on selection of menu.
 *
 *	Change history -
 *
 *		Date 				:	Change description
 *		30th June, 2017 	:	Initial copy
 */

var routerApp = angular.module('srsApp', ['ui.router','angularUtils.directives.dirPagination','angularModalService','ngMessages']);

routerApp.config(function($stateProvider, $urlRouterProvider) {
    
    $urlRouterProvider.otherwise('/home');
	
	$stateProvider
        
        .state('company', {
            url: '/company',
            templateUrl: 'admin/businessUnits/company.html',
			controller: 'companyController'
        })
		
		.state('home', {
            url: '/home',
            templateUrl: 'home/home.html',
        })	 
		
        .state('center', {
            url: '/center',
            templateUrl: 'admin/businessUnits/center.html',
            controller: 'centerController'
        })		
});
angular.module("myApp")
 .controller("companyCtrl", ['$scope','$http','ModalService', function ($scope, $http, ModalService) {
	
	$scope.getCompanyDetails = function() {
		$http.get("http://localhost:8080/service/company/getAllDetails").then(function(response) {
			$scope.myData = response.data;
		});
	}
	 
	$scope.getCompanyDetails();
	
	$scope.showModalAddCompany = function() {
        ModalService.showModal({
            templateUrl: 'modalAddCompany.html',
            controller: "AddModalController"
        }).then(function(modal) {
            modal.element.modal();
            modal.close.then(function(result) {            	
                $scope.message = "You said " + result;
                if(result == 1) {
                	$("#success-alert").alert();
                    $("#success-alert").fadeTo(4000, 500).slideUp(500, function()
                    {
                       $("#success-alert").slideUp(500);
                    });
                    $scope.getCompanyDetails();
                }
                else if (result == 0)
               	{
                	$("#error-alert").alert();
                    $("#error-alert").fadeTo(4000, 500).slideUp(500, function()
                    {
                       $("#error-alert").slideUp(500);
                    });
                }
               
                $('.modal-backdrop').remove();
               
            });
        });
    };
    
	$scope.showModalDeleteCompany = function(x) {
		alert('ID:' + x.company_id);
        ModalService.showModal({
            templateUrl: 'showModalDeleteCompany.html',
            controller: "DeleteModalController",
            inputs: {
                company_id: x.company_id,
            }
        }).then(function(modal) {
            modal.element.modal();
            modal.close.then(function(result) { 
            	$('.modal-backdrop').remove();
            });
        });
    };
 }
 ])
 
 .controller("AddModalController",['$scope','$http','close', function($scope, $http, close) {
	 
	$scope.close = function(result) {
		close(result);
	};
	
	$scope.add = function(company) {
		
	    var dataObj = {
	    		company_id : $scope.company.id,
	    		company_name : $scope.company.name,
	    		company_desc : $scope.company.desc,
				company_type_id : $scope.company.type_id
			};	
	    
		var res = $http.post('http://localhost:8080/service/company/savecompany_json', dataObj);
			
		res.success(function(data, status, headers, config) {			
			close(data);
		});
		
		res.error(function(data, status, headers, config) {
			alert( "Failure message: " + JSON.stringify({data: data}));
		});		
		
	};
 }])
 
 
.controller("DeleteModalController",['$scope','$http','close','company_id', function($scope, $http, close, company_id) {
	 
	$scope.company_id = company_id;
	
	$scope.close = function(result) {
		close(result);
	};
	
    $scope.deleteC = function() {
		
    	alert("In delete operation controller " + $scope.company_id);
		
    	/*var dataObj = {
	    		company_id : $scope.company.id
    	};*/
    	
    	//HTTP DELETE- delete employee by Id
        /*$scope.removeEmployee = function(employee) {
            $http({
                method : 'DELETE',
                url : 'employees/' + employee.id
            }).then(_success, _error);
        };*/
    	
    	var res = $http.delete('http://localhost:8080/service/company/deletecompanyid/' + company_id);
		
    	/*$http({
            method : 'DELETE',
            url : 'http://localhost:8080/service/company/deletecompanyid/' + company_id
        }).then(_success, _error);   WORKING PART WOW CODE */
    	
    	alert("Result: " + res);
    	
		res.success(function(data, status, headers, config) {			
			close(data);
		});
		
		res.error(function(data, status, headers, config) {
			alert( "Failure message: " + JSON.stringify({data: data}));
		});
	};

}]);